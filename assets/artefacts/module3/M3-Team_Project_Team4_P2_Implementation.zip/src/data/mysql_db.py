import mysql.connector

class MySQLDatabase():
	"""This class manages MySQL database connection and cursor lifecycle."""

	def __init__(self):

		self.__conf = {
			'host': 'localhost',
			'read_default_file': '/home/codio/.my.cnf',
			'database': 'iss_auth',
			'ssl_disabled': True # disabled for the localhost implementation
		}
		self.conn = None


	"""
	The following methods are invoked on entry to and exit from the body of the 'with' statement.
	For more information, please refer to: https://www.python.org/dev/peps/pep-0343/
	"""
	def __enter__(self):
		try:
			self.conn = mysql.connector.connect(**self.__conf)
		except mysql.connector.Error as e:
			if e.errno == 2003: # Can't connect to MySQL server
				self.conn = None
		return self


	def __exit__(self, exc_type, exc_value, traceback):
		if self.conn is not None and self.conn.is_connected():
			self.conn.close()


	def execute(self, statement, to_commit):
		"""Performs a single SQL query using a context manager with a cursor object."""

		result = []

		# This code makes use of the so-called 'buffered' cursor. A buffered cursor fetches and
		# buffers the rows of a result set after executing a query. Essentially, the cursor is
		# used as an iterator, without the need in new variables.
		# 
		# For more information, please refer to:
		# https://dev.mysql.com/doc/connector-python/en/connector-python-tutorial-cursorbuffered.html
		#
		# cursor docs: https://dev.mysql.com/doc/connector-python/en/connector-python-api-mysqlconnection-cursor.html
		#

		with self.conn.cursor(buffered=True, dictionary=True) as cursor:
			# this is for statements like INSERT
			if to_commit:
				print(f"Committing statement: {statement}")
				cursor.execute(statement)
				self.conn.commit()
				
				return cursor.lastrowid
			else:
				cursor.execute(statement, multi=False)
				result = cursor.fetchall()

		print ("Output of SQL statement is " + str(result))
		
		return result
