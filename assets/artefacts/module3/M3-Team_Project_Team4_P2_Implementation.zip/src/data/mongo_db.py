from pymongo import MongoClient
from pymongo.errors import ConnectionFailure


class MongoDatabase:
	"""This class encapsulates the management of the MongoDB collection."""

	def __init__(self):
		self.__client = MongoClient('localhost', 27017)
		db = self.__client.issSafetyDB
		db.authenticate('issUser', 's=M^$VC_jpyL_6xF') # for development purposes only
		self.__entries = db.entries


	@property
	def entries(self):
		return self.__entries


	def test_access(self):
		try:
			# This check is based on a recommendation in the MongoClient documentation.
			self.__client.admin.command('ismaster')
			return True
		except ConnectionFailure:
			print("MongoDB server is not available.")
			return False
