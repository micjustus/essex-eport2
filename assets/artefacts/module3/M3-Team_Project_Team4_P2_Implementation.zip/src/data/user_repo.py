import json


class UserRepository():
	"""Provides an abstraction of a MySQL database containing user information."""

	create_table_query = """
	CREATE TABLE users(
		id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		first_name VARCHAR(35) NOT NULL,
		last_name VARCHAR(35) NOT NULL,
		position VARCHAR(50) NOT NULL,
		email VARCHAR(255) NOT NULL,
		username VARCHAR(128) NOT NULL,
		password CHAR(60) NOT NULL,
		access_lvl CHAR(10) NOT NULL,
		CONSTRAINT PRIMARY KEY(id))
	"""

	insert_admin_query = """
	INSERT INTO
		users(first_name, last_name, position, email, username, password, access_lvl)
	VALUES(
		'John', 'Shepard', 'Administrator', 'admin@ict.nasa.gov',
		'admin', '$2y$10$.vGA1O9wmRjrwAVXD98HNOgsNpDczlqm3Jq7KnEd1rVAGv3Fykk1a', '1')
	"""

	insert_user_query = """
	INSERT INTO
		users(first_name, last_name, position, email, username, password, access_lvl)
	VALUES(
		'Miranda', 'Lawson', 'Technology Officer', 'm.lawson@ict.nasa.gov',
		'iamlaw', '$2y$10$.vGA1O9wmRjrwAVXD98HNOgsNpDczlqm3Jq7KnEd1rVAGv3Fykk1a', '2')
	"""

	update_user_query = """
	UPDATE
		users
	SET
		password = '$2a$10$KssILxWNR6k62B7yiX0GAe2Q7wwHlrzhF3LqtVvpyvHZf0MwvNfVu'
	WHERE
		id=2
	"""

	def __execute(self, statement, to_commit=False):
		with MySQLDatabase() as db:
			return db.execute(statement, to_commit)


	def test_access(self):
		return self.__execute("SELECT VERSION()")


	def get_users(self):
		"""Returns a collection of users within the user repository. """
		
		#
		# We do not return security-sensitive information such as 'password' 
		# to the system. To validate a user's password, we leverage the 
		# 'check_user_pwd' function
		#
		
		rows = self.__execute(f"""
			SELECT 
				first_name,
				last_name,
				username,
				email, 
				access_lvl,
				position
				FROM users
			""")
		
		users = []
		
		for row in rows:
			user = self.map_to_user(row)
			users.append(user)
		
		return users


	def get_user_by_id(self, id):
		"""Returns a single user instance specified by the supplied ID. If no user exists, 
		then an empty user instance will be returned."""
		
		row = self.__execute(f"""
		SELECT
			first_name, 
			last_name, 
			username, 
			email,
			position, 
			access_lvl 
			FROM users WHERE id={id}
			""")
		
		return self.map_to_user(row)


	def get_user_id(self, user_name):
		result = self.__execute(f"SELECT IFNULL((SELECT 1 FROM users WHERE username='{user_name}'), 0) as Matched")
		return result[0]['Matched'] == 1
	

	def get_user_by_user_name(self, user_name):
		"""Returns a single user instance specified by the supplied user name. If no user exists,
		then an empty user instance will be returned."""
		
		row = self.__execute(f"""SELECT 
			first_name, 
			last_name, 
			username, 
			email,
			position, 
			access_lvl
			FROM users WHERE username='{user_name}'
			""")

		return self.map_to_user(row)


	def add_user(self, user):
		"""Adds a new user to the underlying database.

		:param user: A user instance to insert.
		:return: The AUTO_INCREMENT number of the inserted user record.
		"""

		self.assert_attributes(user)

		# The insert query has support to return the inserted identity column

		insert_query = f"""
		INSERT INTO
			users(first_name, last_name, position, email, username, password, access_lvl)
		VALUES(
			'{user.first_name}',
			'{user.last_name}',
			'{user.position}',
			'{user.email}',
			'{user.user_name}',
			'{user.password}',
			{user.access_lvl})
		"""

		# We do not want to use dictionary output, because if we did, the output
		# would loook like so "[{'LAST_INSERT_ID()': 13}]"
		
		id = self.__execute(insert_query, True)
		
		# <dictionary>.values() returns a view of the dictionary, 
		# therefore we need to wrap it into a list object
		
		user.id = id #list(id[0].values())[0]
		return user.id


	def update_user(self, user):
		"""Updates a given user's information in the underlying database."""

		# every user instance MUST have an associated DB 'ID' attribute
		# At this point, if there is a missing 'ID' property, it means
		# we might have been 'hacked' or a fictitious User instance was created
		# For instance: 
		# 
		#if not hasattr(user, 'id'):
		#	raise ValueError("Unable to update user without required 'ID' attribute.")
		#
		# In a realworld system, we would not generally pass internal IDs around
		# as part of business objects; delegating instead, the lookup of their IDs
		# based on some "user friendly" field such as user name. AS shown below:
		
		id = self.find_user_id(user.user_name)
		if id == INVALID_ID:
			rais

		self.assert_attributes(user)

		update_query = f"""
		UPDATE
			users
		SET
			first_name = '{user.first_name}',
			last_name = '{user.last_name}',
			position = '{user.position}',
			email = '{user.email}',
			username = '{user.user_name}',
			password = '{user.password}',
			access_lvl = {user.access_lvl}
		WHERE
			id = {user.id}
		"""
		return self.__execute(query, True)


	def delete_user(self, user):
		"""Removes the specified user from """
		if not user:
			return False

		# every user instance MUST have an associated DB 'ID' attribute
		if not hasattr(user, 'id'):
			raise ValueError("Unable to remove a user without required 'ID' attribute.")

		id = self.get_user_id(user.user_name)
		if not id:
			raise ValueError("Unable to remove a user with an invalid 'ID'.")
			
		return self.__execute(f'DELETE FROM users WHERE id={user.id}', True)



	def assert_attributes(self, user):
		"""Ensures a user instance has required attributes for the SQL statements."""
		if not user:
			return

		if not hasattr(user, 'email'):
			user.email = ''

		if not hasattr(user, 'access_lvl'):
			user.access_lvl = ''

		if not hasattr(user, 'password'):
			user.password = ''


	def get_user_pwd(self, user_name, pwd):
		if not user_name or not pwd:
			return False
		
		# We're checking the user's password against whats stored in the DB.
		# We do not care about the *content* of the password at this point as
		# we are simply comparing two values.
		#
		result = self.__execute(f"""SELECT IFNULL((SELECT password FROM users WHERE username='{user_name}'), '') as password""")
				
		print(f"Get user password={result}")
		
		return result[0]['password']
	

	def map_to_user(self, result):
	
		# For this mapping method to work, the 'result' must be a dictionary
		# The mysql connector inside 'mysql_db.py' must be set as
		# 
		# 	self.conn.cursor(buffered=True, dictionary=True) as cursor:
		#
		
		user = User('', '', '', '', 0)
		if not result: 
			return user
		

		if type(result) is list:
			if len(result) == 0:
				return user
		
			if type(result[0]) is not dict:
				return user
		
			dd = result[0]
		else:
			if type(result) is not dict:
				return user
			
			dd = result
		
		for key, value in dd.items():
			if key == "username":
				setattr(user, "user_name", value)
			else:
				setattr(user, key, value)
				
		# We ensure all attributes are present because the data may have been 
		# hacked and some fields removed. In this case, we want our application 
		# to still respond correctly without falling over.
		self.assert_attributes(user)
		
		return user

	
	def user_name_exists(self, user_name):
		
		result = self.__execute(f"""SELECT IFNULL((SELECT 1 FROM users WHERE username='{user_name}'), 0) as Matched""")
		return result[0]["Matched"] == 1
	
		
	def get_user_tokens(self):
		result = self.__execute("SELECT token_value FROM tokens", False)
		tokens = []
		if len(result) == 0:
			return tokens
		
		for val in result:
			tokens.append(val['token_value'])
			
		return tokens
	

	def add_user_token(self, token):
		self.__execute(f"INSERT INTO tokens (token_value) VALUES('{token}')", True)
		
	
	def check_token(self, token):
		result = self.__execute(f"SELECT IFNULL((SELECT 1 FROM tokens WHERE token_value='{token}'), 0) AS Matched", False)
		return result[0]['Matched'] == 1
	

	def check_and_remove_token(self, token):
		result = self.__execute(f"SELECT IFNULL((SELECT 1 FROM tokens WHERE token_value='{token}'), 0) AS Matched", False)
		if result[0]['Matched'] == 1:
			self.__execute(f"DELETE FROM tokens WHERE token_value='{token}'", True)
			return True

		return False
					

from mysql_db import MySQLDatabase
from domain.user import User
