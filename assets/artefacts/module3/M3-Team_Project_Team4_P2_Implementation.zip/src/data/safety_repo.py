from bson.objectid import ObjectId
from mongo_db import MongoDatabase
from safety_entry import SafetyEntry
import urllib.parse


class SafetyRepository():
	"""Provides an interface to a MongoDB database containing a collection of safety entries."""

	def __init__(self):
		self.__entries = MongoDatabase().entries


	"""
	The below methods expose standard CRUD operations (create, read, update, delete).
	For more information, please refer to: https://docs.mongodb.com/manual/crud/
	"""

	# CREATE
	def insert_one(self, entry):
		return self.__entries.insert_one(entry)


	def insert_many(self, entries):
		return self.__entries.insert_many(entries)


	# READ
	def read_all(self):
		return self.__entries.find()


	def find_one(self, condition):
		result = self.__entries.find_one(condition)
		return self.map_to_entry(result)


	def find_many(self, condition):
		return self.__entries.find(condition)


	def find_many_with_text(self, text):
		result = self.__entries.find( { '$text': { '$search': text } } )

		entries = []

		for item in result:
			entry = self.map_to_entry(item)
			entries.append(entry)

		return entries


	# UPDATE
	def update_one(self, condition, value):
		return self.__entries.update_one(condition, value)


	# DELETE
	def delete_one(self, condition):
		return self.__entries.delete_one(condition)


	def delete_many(self, condition):
		return self.__entries.delete_many(condition)


	def map_to_entry(self, result):
		""" For this mapping method to work, the 'result' must be a dictionary """

		if not result:
			return None

		entry = SafetyEntry(None, '', '', '', '', [])

		for key, value in result.items():
			setattr(entry, key, value)

		return entry


if __name__ == "__main__":
	pass

	# TEST
# 	safety_repo = SafetyRepository()

# 	tmp_entry = {'first entry': 42}

# 	result = safety_repo.insert(tmp_entry)
# 	print(result)

# 	tmp_entry1 = {'another entry': 'to be deleted'}
# 	tmp_entry2 = {'another entry': 'to be deleted'}

# 	result = safety_repo.insert_many([tmp_entry1, tmp_entry2])
# 	print(result)

# 	entries = safety_repo.read_all()
# 	for entry in entries:
# 	  print(entry)

# 	entry = safety_repo.find({'_id': ObjectId('614cb684792646c22da171a6')})
# 	print(entry)
# 	print(entry.get('_id'))
# 	print(entry.get('title'))
# 	print(entry.get('body'))

# 	entries = safety_repo.find_many({'creator': 'Andrey Smirnov'})
# 	for entry in entries:
# 	  print(entry)

# 	result = safety_repo.update_one({'_id': ObjectId('614cb684792646c22da171a6')}, 
# 	                            {'$set': {'creator': 'Taylor Edgell'}})
# 	print(result)

# 	result = safety_repo.delete_one({'_id': ObjectId('614ce2f8461a5e4e15f252b3')})
# 	print(result)

# 	result = safety_repo.delete_many({'another entry': 'to be deleted'})
# 	entries = safety_repo.read_all()
# 	for entry in entries:
# 	  print(entry)
