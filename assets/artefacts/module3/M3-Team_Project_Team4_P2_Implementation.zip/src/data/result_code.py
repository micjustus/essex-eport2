from enum import Enum

class ResultCode(Enum):
	ACKNOWLEDGED = 1
	ERROR = 0
