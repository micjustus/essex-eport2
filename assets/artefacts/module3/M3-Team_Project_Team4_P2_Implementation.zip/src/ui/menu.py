"""Required Libraries will be included here """
import authentication
from start_screen import StartScreen

class Menu:
	"""
	Represents the user interface of ISS Application

	Attributes:
		start_screen_options: dict - Dictionary indicating options within the start menu
	"""

	def run(self):
		"""Method to run the user interface"""

		screen = StartScreen()
		screen.show()

		print("Thank you for using ISS Systems International. Remember: We. Are. Watching!")
