from screen import Screen
from authentication import Authentication
from user_repo import UserRepository
from admin import Admin

class AccountDetailsScreen(Screen):

	def __init__(self):
		super().__init__(
			"ISS System - Account Management",
			[
				("Change Details", self.account_change_details, lambda: Authentication.user_logged_on() and not Authentication.is_admin()),
			])


	def account_change_details(self):
		"""Allows a user to change basic details attached to their account. Administrators are not permitted
		to change their details as they are built-in accounts."""

		user = Authentication.logged_on_user()

		if not user.is_valid:
			print("To update account details, please logon with a valid user name.")
			return

		user_name = input("Enter user name: ")
		first_name = input("Enter first name: ")
		last_name = input("Enter last name: ")
		password = input("Enter password: ")
		# Optional: Confirm password

		if user_name == Admin.ADMIN_USER_NAME:
			print ("Sorry but you cannot use a reserved user name.")
			return

		# Send updated user details to the DB
		try:
			user.change_user_details(user_name, first_name, last_name, "")
		except ValueError as ex:
			# this error is raised if the user has insufficient permissions to
			# update their account details
			print(f"Error while updating account details. {ex}")
		else:
			print ("Your account has been created. You may now login.")