from screen import Screen
from entries_screen import EntriesScreen
from account_screen import AccountDetailsScreen
from admin_controls_screen import AdminControlsScreen
from authentication import Authentication

class AppScreen(Screen):

	def __init__(self):
		super().__init__(
			"ISS Safety Database",
			[
				("Logout", self.logout, lambda: Authentication.user_logged_on()),
				("Entries Management", self.db_entries_management, lambda: Authentication.user_logged_on()),
				("Account Management", self.db_account_management, lambda: Authentication.user_logged_on()),
				("Administrator Controls", self.admin_controls, lambda: Authentication.is_admin())
			], False)

	def logout(self):
		"""
		Log out the current user.
		"""
		Authentication.logout()
		self.quit()


	def db_entries_management(self):
		"""
		Method to display the menu of the ISS safety database
		"""

		screen = EntriesScreen()
		screen.show()
		self.refresh()

	def db_account_management(self):
		"""
		Method to display the menu of the ISS safety database
		"""
		screen = AccountDetailsScreen()
		screen.show()
		self.refresh()

	def admin_controls(self):
		"""
		Method to display the menu of the ISS safety database
		"""
		screen = AdminControlsScreen()
		screen.show()
		self.refresh()
