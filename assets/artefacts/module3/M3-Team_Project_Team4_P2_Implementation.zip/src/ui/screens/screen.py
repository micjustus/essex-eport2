import os
from authentication import Authentication

#
# The code uses Console Colours to help zhoozh up the interface. The list of colours
# can be found here: https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
# and generally, in print(...) statements using them looks like "...\033[<fg>;<bg>"
#

class Screen:
	'''
	Represents a single instance of a menu screen that shows a collection of menu
	options and also supports obtaining user inputs.
	'''

	def __init__(self, title, menu_options, allow_quit = True):
		self.title = title
		self.options = menu_options
		self.can_quit = allow_quit
		self.quit_option = len(menu_options) + 1
		self.continue_screen = True


	def show(self):
		'''
		Displays the specified menu options and accepts user inputs.
		This method quits when the user selects the LAST option (the "quit") option
		'''

		os.system("clear")

		# Open the start screen menu method and runs indefinitely
		while self.continue_screen:
			self.__show_screen_options__()

			
			try:
				# Request the users options and sets to variable "choice"
				choice = int(input("Enter an option: "))

			except ValueError:
				# The user possibly did not enter ANY choice
				os.system("clear")
				continue

			except EOFError:
				# Set default option for testing purposes
				choice = self.quit_option

			if choice == self.quit_option:
				if self.can_quit:
					break

			# Prevent out of bounds error by checking the input option
			# against the boundary of the menu items

			# the screen displays menu items starting at "1", however Python
			# arrays are indexed starting at "0", so let's accommodate for that
			# discrepancy here
			if choice >= 1 and choice < self.quit_option:
				action = self.options[choice - 1]

				# Confirm that the given option is in the dictionary
				if action:
					print(f"\n* Executing command: {action[0]}\n")

					# the menu options are a tuple (<title>, <method>)
					action[1]()
				else:
					print("No 'action' defined for choice '{0}'.".format(choice))
			else:
				print("{0} is not a valid choice".format(choice))


	def quit(self):
		"""
		Forces this screen to act as if the user initiated a 'quit' option. This is necessary for 
		scenarios where a screen does not provide an explicit 'quit' option, but such an action is
		taken by some other screen option.
		"""
		self.continue_screen = False


	def refresh(self):
		os.system("clear")


	def __show_screen_options__(self):
		'''
		Builds a list of numerical menu options for a user to select, based on the 
		order supplied by the menu_options
		'''

		user_name = "----------" if not Authentication.logged_on_user() else Authentication.logged_on_user().user_name
		title = "{} (Logged on as: \033[93;40m{}\033[0m, Admin = {})".format(self.title, user_name, Authentication.is_admin())

		print("")
		print(title)
		print("-" * (len(title) - 12)) # '-12' for the console colours
		print("")

		for index, value in enumerate(self.options, 1):

			# Since certain menu items are security-protected,
			# we take opportunity to test their security requirements
			# before displaying
			if len(value) > 2:
				if value[2]:
					canDisplay = value[2]()
					if not canDisplay:
						continue

			print("\t{}. \033[33m{}\033[0m".format(index, value[0]))

		if self.can_quit:
			print("\t{}. \033[33mReturn/Quit\033[0m".format(self.quit_option))

		print("")
