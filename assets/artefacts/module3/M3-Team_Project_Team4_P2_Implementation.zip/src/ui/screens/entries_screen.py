import re
from screen import Screen
from entry_screen import EntryScreen
from authentication import Authentication
from authorisation import Authorisation, Levels
from safety_store import SafetyStore
from result_code import ResultCode

class EntriesScreen(Screen):

	def __init__(self):
		super().__init__(
			"ISS Safety System - Entries Database",
			[
				("List Entries", self.list_entries, lambda: Authentication.user_logged_on()),
				("View Entry", self.view_entry, lambda: Authentication.user_logged_on()),
				("Edit Entry", self.edit_entry, lambda: Authentication.user_logged_on()),
				("Create Entry", self.create_entry, lambda: Authentication.user_logged_on())
			])


	def list_entries(self):
		"""ISS Safety System - Database. Option 1 (Search Entries)"""

		# Check if the user may search for entries in the database
		if not Authorisation.test_logged_on_sys_access_level(Levels.LIST_ENTRIES):
			print ("Sorry, you do not have sufficient permissions to list entries.")
			return

		try:
			search_terms = str(input("Enter search terms separated by whitespace: "))
		except ValueError:
			print("\nUnexpected error, please contact the administrator.")
			return

		if not search_terms:
			print("\nNo search terms were provided.")
			return

		# The built-in str() function surronded by the try except block above is not
		# going to prevent any attempts of malicious input. Therefore, we perform
		# proper sanitisation of the provided string using a regular expression.
		if not re.match('[a-zA-Z0-9\s]+$', search_terms):
			print("\nOnly letters, numbers and spaces are allowed.")
			return

		# TODO: Supply sensitivity condition based on user access level.
		try:
			entries = SafetyStore().search_for_entries(search_terms)
			if not entries:
				print("\nNo safety entries matching these search criteria.")
				return

			print(f"\nFound the following entries:")

			for entry in entries:
				print(f"{entry._id} -> {entry.title}")
		except Exception as e:
			print(f"Insufficient permissions to list entries. Error={e}")


	def view_entry(self):
		"""ISS Safety System - Database. Option 2 (View Entry)"""

		# Check if the user may view contents of a safety entry
		if not Authorisation.test_logged_on_sys_access_level(Levels.VIEW_ENTRY):
			print ("Sorry, you do not have sufficient permissions to view entries.")
			return

		entry, code, error_msg = self.fetch_entry()

		if code == ResultCode.ERROR:
			print(error_msg)
			return

		if not entry:
			print("\nNo entry with this reference number found in the database.")
			return

		print(f"\nThis entry was created on {entry.created} by {entry.creator}.")
		print(f"Title: {entry.title}\nSummary: {entry.summary}")

		if len(entry.keywords) > 1:
			keywords = ', '.join(map(str, entry.keywords))
			print(f"Associated keywords: {keywords}")
		else:
			print(f"Associated keywords: {entry.keywords[0]}")

		if entry.documents:
			if len(entry.documents.keys()) > 1:
				file_names = ', '.join(map(str, entry.documents.keys()))
				print(f"Uploaded documents: {file_names}")
			else:
				print(f"Uploaded documents: {list(entry.documents)[0]}")
		else:
			print("No attached documents.")


	def edit_entry(self):
		"""ISS Safety System - Database. Option 3 (Edit Entry)"""

		# Check if the user may modify contents of a safety entry
		if not Authorisation.test_logged_on_sys_access_level(Levels.EDIT_ENTRY):
			print ("Sorry, you do not have sufficient permissions to edit entries.")
			return

		entry, code, error_msg = self.fetch_entry()

		if code == ResultCode.ERROR:
			print(error_msg)
			return

		if not entry:
			print("\nNo entry with this reference number found in the database.")
			return

		screen = EntryScreen(entry)
		screen.show()


	def create_entry(self):
		"""ISS Safety System - Database. Option 4 (Create Entry)"""

		# Check if the user may create new entries in the database
		if not Authorisation.test_logged_on_sys_access_level(Levels.CREATE_ENTRY):
			print ("Sorry, you do not have sufficient permissions to create entries.")
			return

		try:
			title = str(input("Enter entry title: "))
			summary = str(input("Enter entry summary: "))
			keywords = str(input("Enter keywords separated by comma: "))
		except ValueError:
			print("\nUnexpected error, please contact the administrator.")
			return

		try:
			sensitivity = int(input("Enter sensitivity level (0=High, 1=Medium, 2=Low): "))
		except ValueError:
			print("\nPlease provide a digit matching one of the levels.")
			return

		if not title:
			print("\nNo title was provided.")
			return

		if not summary:
			print("\nNo summary was provided.")
			return

		if not keywords:
			print("\nNo keywords were provided.")
			return

		if sensitivity not in range(0, 3):
			print("\nIncorrect sensitivity level provided.")
			return

		if not re.match('[a-z,]+$', keywords):
			print("Please provide keywords in lowercase letters, separated by commas.")
			return

		try:
			result = SafetyStore().add_entry(title, summary, keywords.split(','), sensitivity)

			if result.acknowledged:
				print(f"\nAdded new entry with a reference number {result.inserted_id}")
			else:
				print("\nError adding entry, please contact the administrator.")
		except:
			print("Insufficient permissions to add entries.")


	def fetch_entry(self):
		"""Fetches a safety entry from the database based on a reference number."""

		# Check if the user may create entries with the specified sensitivity level
		if not Authorisation.test_logged_on_sys_access_level(Levels.SEARCH_ENTRIES):
			print ("Sorry, you do not have sufficient permissions to search entries.")
			return

		try:
			ref_num = str(input("Enter entry reference number: "))
		except ValueError:
			error_msg = "\nUnexpected error, please contact the administrator."
			return (None, ResultCode.ERROR, error_msg)

		if not ref_num:
			error_msg = "\nNo reference number was provided."
			return (None, ResultCode.ERROR, error_msg)

		# The below regular expression will evaluate that the provided string matches
		# the entry reference format. It will expect either numberical digits or lowercase 
		# letters and will evaluate that the length of the string equals 24 characters.
		if not re.match('^[a-z0-9]{24}$', ref_num):
			error_msg = "\nPlease provide a valid reference number."
			return (None, ResultCode.ERROR, error_msg)

		# TODO: Supply sensitivity condition based on user access level.
		try:
			entry = SafetyStore().load_entry(ref_num)
			return (entry if entry else None, ResultCode.ACKNOWLEDGED, '')
		except:
			print("Insufficient permissions to fetch entries.")
