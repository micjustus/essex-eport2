import os, re
from screen import Screen
from authentication import Authentication
from safety_store import SafetyStore

class EntryScreen(Screen):

	def __init__(self, entry):
		super().__init__(
			"ISS System - Entry Management",
			[
				("Add Document", self.add_document, lambda: Authentication.user_logged_on()),
				("View Documents", self.view_documents, lambda: Authentication.user_logged_on()),
				("Delete Entry", self.delete_entry, lambda: Authentication.user_logged_on())
			])
		self.entry = entry


	def add_document(self):
		"""
		Reads contents of a plain text file located on the file system and attaches these
		contents to the currently open entry.
		"""

		# For the purposes of this study project, we hardcode the name and the location of
		# the file and only process plain text content. While storing large files in a
		# database is almost always less preferable than storing them on a system-level 
		# filesystem, MongoDB does have a specification that supports this use case:
		# https://docs.mongodb.com/manual/core/gridfs/#std-label-faq-developers-when-to-use-gridfs
		# GridFS divides files into chunks of 255 kB and reassembles them as needed. This 
		# also means that GridFS can perform operations on arbitrary file sections (such as 
		# skipping to the middle of an audio file without loading it into memory completely).
		# While GridFS is one of the most powerful features of MongoDB, support of binary
		# file formats is outside of the scope of this study assingment.
		filename = 'report.txt'

		try:
			with open(f'assets/{filename}') as file:
				text = file.read()
		except EnvironmentError: # parent of IOError and OSError
			print("\nFailed opening file, please contact the administrator.")
			return

		text = text.encode('ascii', 'ignore').decode() # remove unicode characters
		text = re.sub(r"https?://\S+", '', text) # remove hyperlinks
		text = re.sub(r"<.*?>", '', text) # remove all HTML tags

		try:
			doc_name = str(input("Enter document name (optional): "))
		except ValueError:
			print("\nUnexpected error, please contact the administrator.")
			return

		if doc_name and not re.match('[a-zA-Z0-9\s]+$', doc_name):
			print("\nOnly letters, numbers and spaces allowed in document names.")
			return

		# MongoDB has certain restriction on field names that result in the "." character
		# not being officially suppored in the key names.
		if not doc_name:
			doc_name = os.path.splitext(filename)[0]

		result = SafetyStore().add_document(self.entry._id, doc_name, text)

		if result.acknowledged:
			print(f"\nSuccessfully added new document.")

			# Update the currently open entry. This is an implementation choice that could
			# have been approached differently based on different UI requirements.
			self.entry.documents = SafetyStore().get_documents(self.entry._id)
		else:
			print("\nFailed adding document, please contact the administrator.")


	def view_documents(self):
		"""Displays documents attached to the currently open entry."""

		if not self.entry.documents:
			print(f"There are no documents attached to this entry.")

		# Because we syncronise the state of the local entry with changes in the database,
		# we do not need to fetch new documents in this method.
		for key, value in self.entry.documents.items():
			print(f"Document: {key}\n\n{value}")


	def delete_entry(self):
		"""Removes the currently open entry from the database."""

		try:
			response = str(input("Please confirm entry deletion (Yes/No): "))
		except ValueError:
			print("\nUnexpected error, please contact the administrator.")
			return

		if not response == 'Yes' and not response == 'No':
			print("\nOperation aborted, please try again.")
			return

		if response == 'No':
			return

		# Proceed with entry deletion
		result = SafetyStore().remove_entry(self.entry._id)

		if result.acknowledged:
			print(f"\nSuccessfully deleted entry {self.entry._id}")

			super().__init__(
				"ISS System - Entry Management",
				[
				])
		else:
			print("\nFailed to delete entry, please contact the administrator.")
