from screen import Screen
from authentication import Authentication

class AdminControlsScreen(Screen):

	def __init__(self):
		super().__init__(
			"ISS System - Admin Management",
			[
				("Show Security Log", self.admin_show_security_log, lambda: Authentication.is_admin()),
				("Allocate User Token", self.admin_allocate_token, lambda: Authentication.is_admin()),
				("Show User Tokens", self.show_tokens, lambda: Authentication.is_admin()),
				("Show Users", self.show_users, lambda: Authentication.is_admin())
			])

	def admin_show_security_log(self):
		"""
		Allows an administrator to list all incorrect password attempts against a username.
		"""
		
		password_attempts = Authentication.get_password_log()
		if not password_attempts:
			password_attempts = {}
			
		for attempt in password_attempts:
				print(f"({attempt} : {password_attempts[attempt]})")


	def admin_allocate_token(self):
		"""
		Method to allocate new user tokens which are given to users in order to allow them
		to create their account.
		"""

		# A user (admin or other) should be logged in at this point; however
		# only admins are permitted to allocate user tokens. Although the option
		# to display the menu item "Allocate User Token" is protected by an 
		# authentication reqirement check, we STILL perform the check here
		# to prevent possible hacking attempts/intercepts
		if not Authentication.is_admin():
			print("Only administrators are permitted to allocate user tokens.")
			return

		# If no user is logged in, then we are assuming a STANDARD user wishes to create
		# a new account. Otherwise, if an administrator is logged in, then we want to 
		# allocate new tokens
		tok = Authentication.create_token()
		
		Authentication.allocate_token(tok)
		
		# we perform one more safety check: ensure the token originated from our servers
		if not Authentication.test_token(tok):
			print("A token was intercepted and is no longer valid or not generated.")
		elif tok is not None:
			print(f"A new token is generated: \033[93;40m{tok}\033[0m. Provide this to a new user for their account creation")


	def show_tokens(self):
		"""
		Allows an administrator to list all available user tokens for user account creation.
		"""

		tokens = Authentication.get_tokens()
		if not tokens:
			tokens = []
			
		print ("    {0} tokens available.".format(len(tokens)))

		for tok in tokens:
			print("    * " + tok)
		

	def show_users(self):
		
		repo = UserRepository()
		users = repo.get_users()
		
		for user in users:
			print(f"    * [{'<no user name>' if not user.user_name else user.user_name}] ({user.last_name}, {user.first_name}).")
	
	
from user_repo import UserRepository

