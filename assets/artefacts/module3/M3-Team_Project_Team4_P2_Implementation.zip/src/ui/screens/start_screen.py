from screen import Screen
from app_screen import AppScreen
from admin import Admin
from user import User
from authentication import Authentication
import stdiomask


class StartScreen(Screen):

	def __init__(self):
		super().__init__(
			"ISS System",
			[
				("Login", self.start_screen_login, lambda: not Authentication.user_logged_on()),
				("Logout", self.start_screen_logout, lambda: Authentication.user_logged_on()),
				("Create User", self.start_screen_create_user, lambda: Authentication.is_admin() or not Authentication.user_logged_on()),
				("Show User Tokens", self.show_tokens, lambda: Authentication.is_admin())
			])

	def start_screen_login(self):
		"""
		Method to allow a user to login
		"""

		# Add authentication call here to check for admin
		# This method is essential to allowing an administrator to login
		# For the purpose of this research project, we assume the admin account has a known password
		# which we can test against
		name = input("Enter user name: ")
		
		# Security ALERT! The input characters typed here must be masked to prevent
		# prying eyes from seeing the plain text password
		pwd = stdiomask.getpass(mask='*')

		# Delegate to authentication to create a valid user instance if
		# the password and user name are good
		user = Authentication.login(name, pwd)
		if not user:
			print("Please enter the valid password, and try again.")
		else:
			# User now has access to the Admin functions
			screen = AppScreen()
			screen.show()
			# screen.refresh()


	def start_screen_logout(self):
		"""
		Log out the current user.Log
		"""
		Authentication.logout()
		self.refresh()


	def start_screen_create_user(self):
		"""
		Method to allow a user to create a new account from a token provided by an admin.
		"""

		# If no user is logged in, then we are assuming a STANDARD user wishes to create
		# a new account. Otherwise, if an administrator is logged in, then we want to 
		# allocate new tokens
		if not Authentication.user_logged_on():
			user_name = input ("Enter user name: ")
			first_name = input ("Enter your first name: ")
			last_name = input ("Enter your last name: ")
			token = input ("Enter token provided by Admin: ")
			pwd = stdiomask.getpass(mask='*')

			if not user_name:
				print ("No user name was provided.")
				return

			# Security check: we cannot create user names reserved by a system
			if user_name == Admin.ADMIN_USER_NAME:
				print ("Sorry but you cannot use a reserved user name.")
				return

			if not first_name or not last_name:
				print ("Both the first and last name are required.")
				return

			if not Authentication.check_password(pwd):
				print ("Password checks failed. Please ensure it's at least 8 characters in length and conforms to ISS password policy.")

			if Authentication.test_token(token, True):
				user = User(user_name, first_name, last_name, 'user@email.com', 0)

				hashed = Authentication.encrypt(pwd)
				user.confirm_password(hashed)

				id = user.create()
				if id:
					print ("Your account has been created. You may now login.")
				else:
					print("There was an error creating your account.")
			else:
				print("Sorry, but the token provided is invalid. Please obtain a new one from an admin.")
		else:
			tok = Authentication.allocate_token()

			# we perform one more safety check: ensure the token originated from our servers
			if not Authentication.test_token(tok):
				print("A token was intercepted and is no longer valid or not generated.")
			elif tok is not None:
				print(f"A new token is generated: {tok}. Provide this to a new user for their account creation")


	def show_tokens(self):
		"""
		Allows an administrator to list all available user tokens for user account creation.
		"""

		tokens = Authentication.get_tokens()
		print ("    {0} tokens available.".format(len(tokens)))

		for tok in tokens:
			print("    * " + tok)