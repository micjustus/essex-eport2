import user

class Employee(User):
  '''
  '''
  pass
