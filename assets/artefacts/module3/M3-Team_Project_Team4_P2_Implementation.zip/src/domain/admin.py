import uuid
from user import User


class Admin(User):
    ADMIN_USER_NAME = "admin"

    def __init__(self, first_name, last_name, position):
        """
        Creates a new administrator user instance with the specified name, last name and position. 
        The default access level assigned to the admin is set to "high".
        """
        super().__init__(Admin.ADMIN_USER_NAME, first_name, last_name, 'email@admin.com', position, 0)

    def generate_token(self):
        """
        The administrator user is able to generate new user tokens for users to create their accounts.
        """
        tok = uuid.uuid64()

        Authentication.allocate_token(tok)

    def set_access_level(self, user, levels):
        '''
        Associates access levels to this user instance. This method throws an error if
        either user or levels are invalid.
        '''

        # Ensure we have a valid user instance
        assert user, "Cannot set access levels on a null user"

        # We want to ensure that at least ONE access level is provided
        assert levels, "Levels may not be empty."

        # We do not support assigning unsupported access levels, so
        # let's perform a quick check
        if not Authorisation.validate_access_levels(levels):
            raise ValueError("One or more access levels is unsupported.")

        user.__access_levels = levels
