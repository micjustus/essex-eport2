import uuid
import bcrypt
import re


#
# This class is made a static class with all methods marked as @staticmethod. This is
# because the Authentication class does not hold instance-specific data other than 
# the class variable 'logged_on_user'. However, since we don't want multiple instances of the 
# Authentication class to hang around, each with their own 'logged_on_user' value - and given 
# that this is a research project that supports a single logged on user at a time - it seemed
# best to make this class static.
#
# However, there is the consideration that we could have used class methods or even 
# traditional instance methods. But, in considering realworld scenarios, organisations usually
# have a single authentication server that operates as their central point for authentication 
# (such as Active Directory servers, local or cloud-based). Therefore, the static class attempts
# mimics a similar concept, albeit it in a rudimentary manner.
#


class Authentication:
	"""Provides the means to authenticate a user's login token."""

	__logged_on_user = None
	_instance = None
	
	# having a class variable of list type seems problematic. 
	# Cannot add to it regardless if we use @staticmethod, or instance methods
	# It. is. a. Mystery.
	#tokens = []
	
	password_attempt_log = {}

	@staticmethod
	def get_tokens():
		# In a realworld system, such a function would not exist or at the very least, not best
		# publicly visible. It is so for the research project.

		repo = UserRepository()
		tokens = repo.get_user_tokens()
		
		return tokens
	

	@staticmethod
	def get_password_log():
		# In a realworld system, such a function would not exist or at the very least, not best
		# publicly visible. It is so for the research project.

		return Authentication.password_attempt_log


	@staticmethod
	def logged_on_user():
		"""Returns the logged in user."""

		# In a realworld system, we typically protect information exposed from any 'property'
		if Authentication.__logged_on_user == None:
			return None

		return Authentication.__logged_on_user


	@staticmethod
	def user_logged_on():
		"""Returns True if a user is logged in, False otherwise."""
		return Authentication.__logged_on_user != None


	@staticmethod
	def is_admin():
		"""Returns True if the logged on user is an Administrator user or False otherwise."""
		return isinstance(Authentication.__logged_on_user, Admin)


	@staticmethod
	def login(user_name, pwd):
		"""Attempts to log in the specified user based on their provided token and password.

		:param user_name: the actual user's login name
		:param pwd: the password for the user instance
		:return: a User instance applicable to the logon details
		"""
		if not user_name:
			print("No user instance supplied. Login cannot continue.")
			return False

		# Prevent multiple login attempts of the same user
		if Authentication.__logged_on_user:
			if user_name == Authentication.__logged_on_user.user_name:
				return True

		print(f"Login: user_name={user_name}, password={pwd}")
		
		# validate that the password is correct for the user
		if not Authentication.test_password(user_name, pwd):
			print("Password check failed. Cannot login.")
			
			# Used to log failed password attempts
			if user_name in Authentication.password_attempt_log:
				Authentication.password_attempt_log[user_name] = Authentication.password_attempt_log.get(user_name,0) + 1
				if Authentication.password_attempt_log[user_name] >= 3:
					print("Production Test: Password attempt limit reached")
			else:
				Authentication.password_attempt_log[user_name] = 1
			
			return False

		# We delegate creation of the user account to the User class
		# This is to keep the classes "focused" on their what they 
		# are required to do: User works with users, while Authentication
		# works with authenticating

		user = Authentication.load_user_account(user_name)

		Authentication.__logged_on_user = user
		print(f"{user.user_name} is logged on.")

		return True


	@staticmethod
	def create_user(user_name, first_name, last_name, email, position, password):
		"""Generates a new user instance and persists it to the system user repository."""
		user = User(user_name, first_name, last_name, email, position)

		hashed = Authentication.encrypt(password)
		user.confirm_password(hashed)
		user.create()

		return user


	@staticmethod
	def logout():
		"""Removes the specified user from a login session, thereby preventing their
		access to any system functionality."""

		# In a realworld system, we ought to clear session tokens, cookies and any
		# identifying information that can be tied to the previous logon session.
		# ESPECIALLY of concern, is releasing any computer resources currently held by
		# the previous user.
		Authentication.__logged_on_user = None


	@staticmethod
	def test_token(token, remove=False):
		"""Returns True if the provided token is valid and removes it from the available list of tokens."""

		if not token:
			return False
	
		repo= UserRepository()
		if remove:
			if repo.check_and_remove_token(token):
			#if token in Authentication.tokens:
				#Authentication.tokens.remove(token)
				return True
		else:
			return repo.check_token(token)


	@staticmethod
	def check_password(pwd):
		"""Runs ISS password policy checks on a specified password."""
		
		# Disallow passwords that are less than 8 characters in length
		if not pwd or len(pwd) < 8:
			return False

		# The below regex will ensure that the password contains:
		# - at least one upper case letter (?=.*?[A-Z])
		# - at least one lower case letter (?=.*?[a-z])
		# - at least one digit (?=.*?[0-9])
		# - at least one special character (?=.*?[#?!@$%^&*-])
		if not re.match('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).*$', pwd):
			return False
		
		return True


	@staticmethod
	def test_password(user_name, pwd):
		"""Returns True if the supplied encrypted password compares true with the encrypted password in the DB."""

		#
		# For this research project, we delegate to the DB to make a quick comparison between
		# the password entered by a user and the one stored.
		#
		# In a live system, the password check would be separated from this class and given 
		# to an authorised service to validate the passwords.
		#
		
		if not pwd:
			print("Password cannot be empty.")
			return False
		
		repo = UserRepository()
		hashed = repo.get_user_pwd(user_name, pwd)
		
		if not hashed:
			print(f"Password stored for {user_name} is empty or invalid")
			return False
		
		ec = Authentication.encrypt(pwd)
		print(f"Test user password={ec}")
		
		return bcrypt.checkpw(bytes(pwd, "utf-8"), bytes(hashed, "utf-8"))


	@staticmethod
	def encrypt(value):
		# Hash a password for the first time
		#   (Using bcrypt, the salt is saved into the hash itself)
		
		return bcrypt.hashpw(bytes(value, 'utf-8'), bcrypt.gensalt()).decode('utf-8')


	@staticmethod
	def create_token():
		if not Authentication.is_admin():
			print("Only an administrator may allocate user tokens.")
			return ""

		# We use uuid4() because it leverates a random number generator. 
		# uuid1() contains the host machine's MAC address, so best to avoid it
		# https://www.rfc-editor.org/rfc/rfc4122

		# this can be added to the token list...
		token = uuid.uuid4()

		return str(token).replace("-", "")


	@staticmethod
	def allocate_token(token):
		if not Authentication.is_admin():
			print("Only an administrator may allocate user tokens.")
			return ""

		# the class variable is problematic, WHETHER ACCESSED VIA AN INSTANCE or NOT
		# So, instead, jsut write the token to DB
		repo = UserRepository()
		repo.add_user_token(token)
		
		#Authentication.tokens.append(token)

	
	@staticmethod
	def load_user_account(user_name):
		"""
		Returns an account instance for this user that holds information related to
		the safety entries and reports authored by this user.
		"""
		
		db = UserRepository()
		user = db.get_user_by_user_name(user_name)
		
		if user_name == Admin.ADMIN_USER_NAME:
			user = Admin(user.first_name, user.last_name, user.position)
		else:
			user = User(user_name, user.first_name, user.last_name, user.email, user.position)
			
		user.access_lvl = user.access_lvl
		
		return user
	
	
from user_repo import UserRepository
from admin import Admin
from user import User
