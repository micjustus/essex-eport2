from enum import Enum, auto
from authentication import Authentication

# This enumeration class holds values representing allowable actions. It
# forms part of the Authorisation section of this project

class Levels(Enum):
	CHANGE_PASSWORD = auto()
	CHANGE_DETAILS = auto()
	GET_ACCOUNT = auto()
	
	#Entry permissions
	CREATE_ENTRY = auto()
	CREATE_ENTRY_REPORT_ISSUE = auto(),
	DOWNLOAD_ENTRY_DOC = auto()
	EDIT_ENTRY = auto()
	EDIT_ENTRY_LINKS = auto()
	EDIT_ENTRY_DOC = auto()
	LIST_ENTRIES = auto()
	REMOVE_ENTRY = auto()
	SEARCH_ENTRIES = auto()
	VIEW_ENTRY = auto()
	
	# Report permissions
	AMEND_REPORT_ACTION = auto()
	AMEND_REPORT_OUTCOME = auto()
	AMEND_REPORT_STATUS = auto()
	EDIT_REPORT = auto()
	LOAD_REPORT = auto()
	LOAD_REPORTS = auto()
	


class Authorisation:

	"""	Represents a level of MAC (Mandatory Access Control) within the ISS system"""

	# Contains a mapping between user types and the type of system access levels permitted
	# Managing system permissions is done through this collection of permissions. Each "high", "low"
	# or "medium" entry refers to Admin, User or Contractors.
	__sys_access_definitions = {
		# An admin user
		0 : [ Levels.LOAD_REPORT, Levels.EDIT_REPORT, Levels.AMEND_REPORT_ACTION, Levels.AMEND_REPORT_OUTCOME, Levels.AMEND_REPORT_STATUS,
			 Levels.LIST_ENTRIES, Levels.SEARCH_ENTRIES, Levels.CREATE_ENTRY, Levels.REMOVE_ENTRY,
			 Levels.EDIT_ENTRY, Levels.EDIT_ENTRY_DOC, Levels.DOWNLOAD_ENTRY_DOC, Levels.CREATE_ENTRY_REPORT_ISSUE,
			 Levels.VIEW_ENTRY,
			 Levels.CHANGE_PASSWORD
			],

		# A contractor user
		1 : [Levels.CHANGE_DETAILS, Levels.LIST_ENTRIES, Levels.LOAD_REPORTS,
			 Levels.SEARCH_ENTRIES, Levels.CREATE_ENTRY, Levels.REMOVE_ENTRY,
			 Levels.EDIT_ENTRY, Levels.EDIT_ENTRY_LINKS, Levels.EDIT_ENTRY_DOC 
			],

		# A standard user
		2 : [Levels.CHANGE_DETAILS, Levels.LOAD_REPORTS, Levels.LIST_ENTRIES, Levels.SEARCH_ENTRIES, Levels.VIEW_ENTRY, Levels.CHANGE_PASSWORD ]
	}


	# Contains a mapping of access permissions quantitive values
	__db_access_definitions = {
		"High" : 0,
		"Medium":  1,
		"Low":  2
	}


	@staticmethod
	def test_logged_on_sys_access_level(action):
		"""
		Determines if the user instance is an Admin, which permits management of users and
		grants unrestricted access to the software system.
		"""

		if not Authentication.user_logged_on():
			return False
		
		user = Authentication.logged_on_user()

		result = Authorisation.test_sys_access_level(action, user.access_lvl)
		print(f"test_logged_on: user={user.user_name}, access_level={user.access_lvl}, success={result}")
		
		return result

	
	@staticmethod
	def test_sys_access_level(action, access_level):
		"""
		Determines if the user instance is an Admin, which permits management of users and
		grants unrestricted access to the software system.
		"""

		result = True
		
		if not access_level in Authorisation.__sys_access_definitions:
			result = False
		else:
			levels = Authorisation.__sys_access_definitions[access_level]
			if not levels:
				result = False
			else:
				result = action in levels

		print (f"test_sys_access_level: action={action}, access_level={access_level}, success={result}")
		
		return result
	

	@staticmethod
	def test_db_access_level(action):
		"""
		Given a 'user' instance, returns True or False if the specified user
		has the required level of access.
		"""

		# This method is testing against the logged in user
		if not Authentication.user_logged_on():
			return False

		user = Authentication.logged_on_user()
		
		# Assign the access value relative to the level name for comparison
		user_access_value = get_level_value(user.access_lvl)
		entry_access_value = get_level_value(access_level)

		# Step 1: Check if user allowed to access entry
		if not user_access_value <= entry_access_value:
			#raise ValueError("User not permitted to perform the specified action for this DB operation.")
			return False

		# Step 2: Confirm if requested action is allowed
		if not test_sys_access_level(action, entry_access_level):
			#raise ValueError("User not permitted to perform the specified action for this DB operation.")
			return False
		
		return True

	
	@staticmethod
	def try_test_db_access_level(user, action, access_level):
		"""
		This implementation wraps 'test_db_access_level' in a try..catch so that callers are not 
		required to use try..catch blocks in their code.
		"""

		try:
			return test_db_access_level(user, action, access_level)
		except ValueError:
			print("User not permitted to perform the specified action for this DB operation.")
			return False

		
	@staticmethod
	def get_level_value(access_level):
		"""
		Used to return the value of each access level for comparison purposes
		"""

		for level in __db_access_definitions:
			if access_level == level["Level"] :
				return level["Value"]

		return "False"


	@staticmethod
	def validate_access_levels(access_level):
		"""
		NEW! Determines if each entry specified in the access level is supported 
		by the system.
		"""
		for level in __db_access_definitions:
			if access_level == level["Level"] :
				return True

		return False
