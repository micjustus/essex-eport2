from bson.objectid import ObjectId
from datetime import datetime
from auth.authorisation import Authorisation, Levels
from authentication import Authentication
from safety_repo import SafetyRepository
from safety_entry import SafetyEntry

class SafetyStore:
	"""Provides operations that can be performed on items in the safety database."""


	def search_for_entries(self, terms):
		"""
		Supports searching for safety entries given properly formatted search terms.
		The properties searched include 'Title', 'Summary' or 'Keywords'.
		"""

		if not Authorisation.test_logged_on_sys_access_level(Levels.SEARCH_ENTRIES):
			raise ValueError("User is not authorised to search for entries.")
			#print("User is not authorised to search for entries.")
			#return

		return SafetyRepository().find_many_with_text(terms)


	def load_entry(self, ref_num):
		"""Gets a single safety entry from the database based on reference number."""

		if not Authorisation.test_logged_on_sys_access_level(Levels.VIEW_ENTRY):
			raise ValueError("User is not authorised to search for entries.")
			#print("User is not authorised to search for entries.")
			#return 

		return SafetyRepository().find_one({'_id': ObjectId(ref_num)})


	def add_entry(self, title, summary, keywords, sensitivity):
		"""Adds a new safety entry into the database."""

		if not Authorisation.test_logged_on_sys_access_level(Levels.CREATE_ENTRY):
			raise ValueError("User is not permitted to add database entries.")
			#print("User is not permitted to add database entries.")
			#return 

		# Validate that we do not already have an existing entry
		match_entry = SafetyRepository().find_one({'title': title})

		if match_entry:
			print("An entry already exists with the specified title.")
			return

		# Prepare some of the mandatory entry attributes
		curr_user = Authentication.logged_on_user()
		full_name = curr_user.first_name + " " + curr_user.last_name
		today_date = datetime.today().strftime('%Y-%m-%d')

		# Insert new entry into the database
		return SafetyRepository().insert_one({
			"created": today_date,
			"creator": full_name,
			"title": title,
			"summary": summary,
			"keywords": keywords,
			"related": [],
			"documents": {},
			"sensitivity": sensitivity
		})


	def add_document(self, ref_num, name, content):
		"""Adds a single document to the specified safety entry."""

		if not Authorisation.test_logged_on_sys_access_level(Levels.EDIT_ENTRY_DOC):
			raise ValueError("Unable to upload entry document.")
			#print("Unable to upload entry document.")
			#return False

		return SafetyRepository().update_one({'_id': ObjectId(ref_num)},
											 {'$set': {f'documents.{name}': content}});


	def get_documents(self, ref_num):
		"""Retrieves documents attached to a safety entry."""

		if not Authorisation.test_logged_on_sys_access_level(Levels.LOAD_REPORT):
			raise ValueError("Unable to upload entry document.")
			#return False

		entry = SafetyRepository().find_one({'_id': ObjectId(ref_num)})
		return {} if not entry else entry.documents


	def remove_entry(self, ref_num):
		"""Removes a specified safety entry from the database."""

		if not Authorisation.test_logged_on_sys_access_level(Levels.REMOVE_ENTRY):
			raise ValueError("User is not permitted to add database entries.")
			#print("User is not permitted to add database entries.")
			#return False

		return SafetyRepository().delete_one({'_id': ObjectId(ref_num)})
