#from auth.authorisation import Authorisation
from authentication import Authentication
#import safety_store

class Account():
  '''

  '''

  def __init__(self, user):
    self.__user = user


  def load_authored_safety_entries(self):
    '''
    Returns a set of all the entries authored by this user.
    '''

    # To be secure, we OUGHT TO ensure the assigning user has
    # the correct permissions to update details
    if not Authorisation.test_access_level(Levels.LOAD_ENTRIES):
        raise ValueError("Unable to load authored entries.")

    db = SafetyDb()
    entries = db.load_entries_by_user(self.__user.__user_name)

    return entries


  def load_related_reports(self):
    '''
    Returns a set of all the reports associated to safety entries authored by this user.
    '''

    # To be secure, we OUGHT TO ensure the assigning user has
    # the correct permissions to update details
    if not Authorisation.test_access_level(Levels.LOAD_REPORTS):
        raise ValueError("Unable to load authored entry reports.")

    db = SafetyDb()
    entries = db.load_entry_reports_by_user(self.__user.__user_name)

    return entriese