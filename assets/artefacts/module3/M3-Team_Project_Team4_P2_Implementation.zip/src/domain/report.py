from auth import Authorisation, Levels

class Report:
  '''
  Represents a single standard report associated to a safety entry.
  '''

  def __init__(self, title, status, severity, outcome, action):
    '''
    Initialises a new instance of this standard report.
    '''

    self.__title = title
    self.__status = status
    self.__severity = severity
    self.__outcome = outcome
    self.__action = action


  def edit_details(self, title, status, severity, outcome, action):
    '''
    '''
    if not Authorisation.test_access_level(Levels.EDIT_REPORT):
        raise ValueError("Unable to amend report details.")


  def add_action(self, action):
    '''
    '''
    if not Authorisation.test_access_level(Levels.AMEND_REPORT_ACTION):
        #raise ValueError("Unable to amend report's action.")  
		print("Unable to amend report's action.")
		return False


  def add_outcome(self, outcome):
    '''
    '''
    if not Authorisation.test_access_level(Levels.AMEND_REPORT_OUTCOME):
        raise ValueError("Unable to amend report's outcome.")   


  def update_status(self, status):
    '''
    '''
    if not Authorisation.test_access_level(Levels.AMEND_REPORT_STATUS):
        #raise ValueError("Unable to amend report's status.")  
		print ("Unable to amend report's status.")
		return False