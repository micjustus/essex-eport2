import uuid


class User():
	"""
	Contains functionality related to users of the system.
	"""

	def __init__(self, user_name, first_name, last_name, email, position, access_levels = 2):
		"""Initializes a new instance of this User class."""
		self.__user_id = uuid.uuid4().hex
		self.password = ''
		self.email = email
		self.first_name = first_name
		self.last_name = last_name
		self.user_name = user_name
		self.position = position
		self.access_lvl = access_levels


	@property
	def is_valid(self):
		"""Returns True if this instance contains valid data to represent a user, or False otherwise. 
		An invalid user instance is one with no first name, last name or user name."""

		return (self.first_name and self.last_name) or self.user_name


	def confirm_password(self, value):
		"""
		Sets this user instance's password to the new value.
		"""

		# To be secure, we OUGHT TO ensure the assigning user has
		# the correct permissions to set a new password. We will
		# discuss in the Team Meeting on a suitable approach
		print(f"Confirm user can set password: AccessLevel={self.access_lvl}")
		
		if not Authorisation.test_sys_access_level(Levels.CHANGE_PASSWORD, self.access_lvl):
			raise ValueError("Insufficient permissions to set password.")

		# The supplied password must already be encrypted. This should
		# take place via the Authentication.create_user functionality
		self.password = value


	def create(self):
		
		db = UserRepository()
		if db.user_name_exists(self.user_name):
			print(f"Sorry, but this user name is already taken. {self.user_name}")
			return False
		else:
			id = db.add_user(self)
			print(f"New DB user created with ID: {id}")
			return id > 0
	
		
	def remove(self):
		db = UserRepository()
		try:
			return db.delete_user(self)
		except ValueError as e:
			return False
		

	def change_user_details(self, user_name, first_name, last_name, position):
		"""
		Allows a user to change any public information, except for access levels and password.
		"""

		# To be secure, we OUGHT TO ensure the assigning user has
		# the correct permissions to update details
		if not Authorisation.test_sys_access_level(Levels.CHANGE_DETAILS, self.access_lvl):
			raise ValueError("Unable to set new user details or you do not have sufficient permission.")

		self.user_name = user_name
		self.first_name = first_name
		self.last_name = last_name
		self.position = position
		
		repo = UserRepository()
		repo.update_user(self)


	def __str__(self):
		return f"(Full name={self.first_name} {self.last_name}, Access_Level={self.access_lvl})"
	
from user_repo import UserRepository
#from auth.authorisation import Authorisation, Levels
from authorisation import Authorisation, Levels
