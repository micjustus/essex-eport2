
class SafetyEntry:
	"""Represents a single safety entry for the system."""

	def __init__(self, object_id, created, creator, title, summary, keywords, 
				 related=[], documents={}, required_access=2):
		self._id = object_id
		self.created = created
		self.creator = creator
		self.title = title
		self.summary = summary
		self.keywords = keywords
		self.related = related
		self.documents = documents
		self.access_level = required_access
