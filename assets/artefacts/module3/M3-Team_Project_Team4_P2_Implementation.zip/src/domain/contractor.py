import user

class Contractor(User):
  '''
  '''
  pass

