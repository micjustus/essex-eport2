# Linking system paths
import sys

sys.path.append('src')
sys.path.append('src/data')
sys.path.append('src/domain')
sys.path.append('src/domain/auth')
sys.path.append('src/ui')
sys.path.append('src/ui/screens')

# Importing required libraries
from flask import Flask, jsonify, request, Response, make_response
from flask_httpauth import HTTPBasicAuth, HTTPTokenAuth
from flask_restful import Api, Resource, reqparse

from datetime import datetime, timedelta
import os
import base64
import re

from safety_store import SafetyStore
from authentication import Authentication
from user_repo import UserRepository
from authorisation import Authorisation, Levels

# This file contains the API for the ISS Safety system that we are developing.
#
# We decided to create an API that fits cohesively on top of the monolythic
# approach using much of the same bussiness logic.
#
# In order to priorities security we have implimented a system of timed access tokens,
# as well as using regular expressions to sanitise input
#
# Some parts of the system are currently theoretically insecure, 
# i.e storing session tokens in a dict, but this has been done
# due to time constrtaints to show a functional project
#
# In a real system many of the security precuations would be more complex, and comprehensively created

# Initialising API
app = Flask(__name__)
api = Api(app)

# Setting extensions
basic_auth = HTTPBasicAuth()
token_auth = HTTPTokenAuth()

#Setting argument parser
parser = reqparse.RequestParser()


class ApiAuth(Resource):

	"""
		Class with contains all methods related to authentication within the API.
		Primarily contains the control of the session tokens
	"""

	# While storing tokens in a dict is inherently insecure, 
	# this satisfies our requirements given the time contraints
	# Alternative approach would be used, such as storing in a seperate DB, in a real system
	token = {}

	@basic_auth.login_required
	def get(self):
		"""
		Method to display the token to the user in JSON format
		"""

		display = self.generate_token()
		return jsonify({'token': list(display.keys())})


	def generate_token(self, expires_in=3600):
		"""
		Method to generate a random access token, and set a usable time of hour to the token
		"""
		now = datetime.utcnow()
		user = Authentication.logged_on_user()
		self.token[base64.b64encode(os.urandom(24)).decode('utf-8')] = [now + timedelta(seconds=expires_in), user]
		return self.token


	def revoke_token(self, token):
		"""
		Method to remove tokens from dict once they have expired
		"""
		del ApiAuth.token[token]


	@staticmethod
	def check_token(token):
		"""
		Method to confirm that both the token exists within the library and has not passed expiriy time
		"""

		try:
			user = ApiAuth.token[token][1]
		except KeyError:
			user = None

		if user is None:
			return None
		elif ApiAuth.token[token][0] < datetime.utcnow():
			ApiAuth.revoke_token()
			return None
	
		Authentication.__user = user
		print (Authentication.logged_on_user())

		return user


class DbSearch(Resource):
	
	"""
		Class that contains the method to allow the API to search for specific safety entries
	"""
	@token_auth.login_required
	def get(self, search_string):
	
		#Error checking
		try:
			search_terms = search_string
		except ValueError:
			return jsonify({'Error 500': 'Unexpected error, please contact administrator'})

		#Confirms input in not blank
		if not search_terms:
			return jsonify({'Error 400': 'Bad request, no search terms'})

		#Sanitisation of the provided input using a regular expression.
		if not re.match('[a-zA-Z0-9\s]+$', search_terms):
			return jsonify({'Error 400': 'Bad request, invalid input'})

		entries = SafetyStore().search_for_entries(search_terms)
		if not entries:
			return jsonify({'Error 204': 'Successful request, no content'})

		# Creates a string of the found entries and outputs it in JSON in a specified format
		output = []
		for entry in entries:
			output.append((f"{entry._id} -> {entry.title}"))

		response = jsonify(output)
		response.headers['Content-Type'] = 'text/plain'
		return response
		#return jsonify(output)


class DbEntry(Resource):

	"""
		Class that contains the methods to allow the API to open, create and delete entries
	"""

	@token_auth.login_required
	def get(self, entry_id):
		"""
		Method to retrieve a specified entry
		"""

		#Error checking
		try:
			ref_num = entry_id
		except ValueError:
			return jsonify({'Error 500': 'Unexpected error, please contact administrator'})

		#Confirms input in not blank
		if not ref_num:
			return jsonify({'Error 400': 'Bad request, empty retrieval input'})

		# Sanitisation of the provided input using a regular expression.
		if not re.match('^[a-z0-9]{24}$', ref_num):
			return jsonify({'Error 400': 'Bad request, invalid input'})

		# TODO: Supply sensitivity condition based on user access level.
		entry = SafetyStore().load_entry(ref_num)

		if not entry:
			return jsonify({'Error 204': 'Successful request, no content'})

		#As MondoDB objects are not iterable with jsonify, string entry must be converted to a string
		results = entry.__dict__
		results['_id'] = str(results['_id'])

		response = jsonify(results)
		response.headers['Content-Type'] = 'text/plain'
		return response


	#used to delete an entry
	@token_auth.login_required
	def delete(self, entry_id):
		"""
		Method to delete a specified entry
		"""

		result = SafetyStore().remove_entry(entry_id)

		if result.acknowledged:
			return jsonify('Entry Deleted')
		else:
			return jsonify({'Error 500': 'Unexpected error, entry not deleted please contact administrator'})


class DbEntryCreate(Resource):

	"""
		Class that contains the method to allow the API to create a new entry
	"""

	@token_auth.login_required
	def post(self):
		"""
		Method to create an entry
		"""
		parser.add_argument('title')
		parser.add_argument('summary')
		parser.add_argument('keywords')
		parser.add_argument('sensitivity', type=int)
		args = parser.parse_args()

		if not Authorisation.test_logged_on_sys_access_level(Levels.CREATE_ENTRY):
			return jsonify({'Error 400': 'Bad request, invalid permissions'})

		try:
			title = args['title']
			summary = args['summary']
			keywords = args['keywords']
		except ValueError:
			return jsonify({'Error 500': 'Unexpected error, please contact administrator'})

		try:
			sensitivity = args['sensitivity']
		except ValueError:
			return jsonify({'Error 400': 'Bad request, invalid sensitivity'})

		if not title:
			return jsonify({'Error 400': 'Bad request, No title'})

		if not summary:
			return jsonify({'Error 400': 'Bad request, No summary'})

		if not keywords:
			return jsonify({'Error 400': 'Bad request, No keywords'})

		if sensitivity not in range(0, 3):
			return jsonify({'Error 400': 'Bad request, invalid sensitivity'})

		if not re.match('[a-z,]+$', keywords):
			return jsonify({'Error 400': 'Bad request, Incorrect keyword format'})

		try:
			result = SafetyStore().add_entry(title, summary, keywords.split(','), sensitivity)

			if result.acknowledged:
				return jsonif(f"\nAdded new entry with a reference number {result.inserted_id}")
			else:
				return jsonify({'Error 500': 'Unexpected error, please contact administrator'})
		except:
			return jsonify({'Error 400': 'Bad request, invalid permissions'})


class DbEntryDownload(Resource):

	"""
		Class that contains the method to allow the API to download documents related to a specified entry
	"""

	@token_auth.login_required
	def get(self, entry_id):
		entry = SafetyStore().load_entry(entry_id)

		output = entry.__dict__
		output['_id'] = str(output['_id'])

		filename = str(entry_id + '.json')

		response = make_response(output)
		response.headers['Content-Type'] = 'application/json'
		response.headers["Content-Disposition"] = f"attachment; filename='{filename}'"
		return response

	
# Adapted from http://polyglot.ninja/securing-rest-apis-basic-http-authentication-python-flask/
# Functionality from flask_httpauth, allows function to be called via login_required decorator for password verification
@basic_auth.verify_password
def verify(username, password):
	"""
		Function to check the DB to confirm a users provided password against
	"""

	user = Authentication.logout()

	if not username and not password:
		return False

	print(f"(API) Testing {password}")

	user = Authentication.login(username, password)
	if user:
		return True


#Functionality from flask_httpauth, allows function to be called via login_required decorator for token verification
@token_auth.verify_token
def verify_token(token):
	"""
		Function to check the vality of the session token by valling method in APIAuth class
	"""
	return ApiAuth.check_token(token) if token else None


# Functionality from flask_httpauth, allows an error to be raised if it is found that a users password is unverified
@basic_auth.error_handler
def basic_auth_error(status):
	if status == 401:
		return jsonify({'Error 401': 'Bad request, invalid input'})
	else:
		return jsonify({'Error 500': 'Unexpected error, please contact administrator'})

	
# Functionality from flask_httpauth, allows an error to be raised if it is found that a token in invlaid or expired
@token_auth.error_handler
def basic_auth_error(status):
	if status == 401:
		return jsonify({'Error 401': 'Bad request, invalid token'})
	else:
		return jsonify({'Error 500': 'Unexpected error, please contact administrator'})


# Set endpoints for created classes
api.add_resource(ApiAuth, "/tokens")	
api.add_resource(DbSearch, "/search/<string:search_string>")
api.add_resource(DbEntry, "/entry/<string:entry_id>")
api.add_resource(DbEntryCreate, "/entry/new")
api.add_resource(DbEntryDownload, "/entry/download/<string:entry_id>")

app.run(debug=True)
app.run(ssl_context='adhoc', host='0.0.0.0')

#Command list:
# curl --user name:password http://127.0.0.1:5000/tokens
# curl -H "Authorization: Bearer token" http://127.0.0.1:5000/search/search_string
# curl -H "Authorization: Bearer token" http://127.0.0.1:5000/entry/download/entry_id
# curl -H "Authorization: Bearer token" http://localhost:5000/entry/new -d "title=Crash report no.5" -d "summary=This is a crash report" -d "keywords=crash" -d "sensitivity=0" -X POST
# curl -H "Authorization: Bearer sY/WruyuYs5PH6Xj9ce0CLjAWhCDAjn8" http://localhost:5000/entry/617138d181cde7090a6ba74c -X delete
# w3m -header "Authorization: Bearer token" http://127.0.0.1:5000/entry/download/6165b89a7145b0a1ab1bd936
