import sqlite3

print(f'SQLite Version is: {sqlite3.sqlite_version}')
print(f'DB-API Version is: {sqlite3.version}')
