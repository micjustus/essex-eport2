import sys, os
import unittest
import uuid

sys.path.append('src')
sys.path.append('src/data')
sys.path.append('src/domain')
sys.path.append('src/domain/auth')
sys.path.append('src/ui')
sys.path.append('src/ui/screens')
sys.path.append('tests/')



from user import User
from user_repo import UserRepository


class UserDataTests(unittest.TestCase): 
	
	def test_get_users(self):
		# simulate that nouser is currently logged on
		repo = UserRepository()
		result = repo.get_users()
		self.assertGreater(len(result), 0) 
     

	def test_add_user(self):
		user = User('unit_test_username', 'first', 'last', 'ut@python.com', '')
		repo = UserRepository()
		
		try:
			result = repo.add_user(user)
		finally:
			if result > 0:
				repo.delete_user(user)
		
		self.assertGreater(result, 0)
		

	def test_get_user_by_username(self):
		user = User('unit_test_username', 'first', 'last', 'ut@python.com', '')
		repo = UserRepository()
		
		try:
			result = repo.add_user(user)
			res = repo.get_user_by_user_name(user.user_name)
			self.assertEqual(user.user_name, res.user_name)
		except:
			raise
		finally:
			if result > 0:
				repo.delete_user(user)

	
	def test_get_user_id(self):
		user = User('unit_test_username', 'first', 'last', 'ut@python.com', '')
		repo = UserRepository()
		
		try:
			result = repo.add_user(user)
			id = repo.get_user_id(user.user_name)
			self.assertTrue(id)
		except:
			raise
		finally:
			if result > 0:
				repo.delete_user(user)
		

	def test_delete_user(self):
		user = User('unit_test_username', 'first', 'last', 'ut@python.com', '')
		repo = UserRepository()
		
		try:
			result = repo.add_user(user)
		except:
			raise
		finally:
			if result > 0:
				repo.delete_user(user)
		
		res = repo.get_user_by_user_name(user.user_name)
		self.assertFalse(res.is_valid)
	

		
# Disable
def disable_print():
    sys.stdout = open(os.devnull, 'w')

# Restore
def enable_print():
    sys.stdout = sys.__stdout__


if __name__ == '__main__':
	
	try:
		# we don't want out standard calls to "print()" to show during testing
		disable_print()
		
		unittest.main()
	finally:
		enable_print()
		#print("done")
