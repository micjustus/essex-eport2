import sys, os
import unittest
import uuid

sys.path.append('src')
sys.path.append('src/data')
sys.path.append('src/domain')
sys.path.append('src/domain/auth')
sys.path.append('src/ui')
sys.path.append('src/ui/screens')
sys.path.append('tests/')

from auth.authorisation import Authorisation, Levels
from authentication import Authentication
from user import User


class AuthenticationTests(unittest.TestCase): 
	
	def test_logout(self):
		# simulate that nouser is currently logged on
		Authentication.logout()
		self.assertFalse(Authentication.user_logged_on()) 
     

	def test_authentication_log_in_admin(self):
		Authentication.logout()
		Authentication.login("admin", "Admin123!")
		self.assertTrue(Authentication.is_admin())
		

	def test_authentication_log_in_user(self):
		Authentication.logout()
		self.assertTrue(Authentication.login(username, "Unit_test@123"))

	
	def test_authentication_log_in_bad_1(self):
		Authentication.logout()
		self.assertFalse(Authentication.login("non-existent", "bad-password"))
		

	def test_authentication_log_in_bad_2(self):
		Authentication.logout()
		self.assertFalse(Authentication.login("", ""))
		
	
	def test_authentication_log_in_locked_policy(self):
		Authentication.logout()
		
		# We are emulating a failed login for 3 attempts
		Authentication.login("", "password1")
		Authentication.login("", "ojk7$0918")
		self.assertFalse(Authentication.login("", "SamplePassword:2084812!!!"))
		
		# but right after another valid user could login...but
		self.assertTrue(Authentication.login(username, "Unit_test@123"))
		

class AuthorisationTests(unittest.TestCase):
	
	def test_authorisation_admin_permitted(self):
		Authentication.logout()
		Authentication.login("admin", "Admin123!")
		
		# we test one of the permissions setup for the Admin level
		self.assertTrue(Authorisation.test_logged_on_sys_access_level(Levels.VIEW_ENTRY))
	
		
	def test_authorisation_admin_not_permitted(self):
		Authentication.logout()
		Authentication.login("admin", "Admin123!")
		
		# we test one of the permissions setup which an Admin might not have access to
		self.assertFalse(Authorisation.test_logged_on_sys_access_level(Levels.CHANGE_DETAILS))
		
		
	def test_authorisation_user_permitted(self):
		Authentication.logout()
		Authentication.login(username, "Unit_test@123")
		
		# we test one of the permissions setup which a standard user has access to
		self.assertTrue(Authorisation.test_logged_on_sys_access_level(Levels.LIST_ENTRIES))
		

	def test_authorisation_user_not_permitted(self):
		Authentication.logout()
		Authentication.login(username, "Unit_test@123")
		
		# we test one of the permissions setup which a standard user has access to
		self.assertFalse(Authorisation.test_logged_on_sys_access_level(Levels.EDIT_ENTRY))		
		
		
class PasswordTests(unittest.TestCase):
	
	def test_password_policy_bad_1(self):
		self.assertFalse(Authentication.check_password("sample"))
		

	def test_password_policy_bad_2(self):
		self.assertFalse(Authentication.check_password("123456"))

		
	def test_password_policy_bad_3(self):
		self.assertFalse(Authentication.check_password("AAAA"))

	
	def test_password_policy_good_1(self):
		self.assertTrue(Authentication.check_password("SampleTest123!!!"))


	def test_password_policy_good_1(self):
		self.assertTrue(Authentication.check_password("1@two*ThreeFOUR"))
		

	def test_user_password_in_DB_fail(self):
		self.assertFalse(Authentication.test_password(username, "THIS is the incorrect password"))
		

	def test_user_password_in_DB_succeed(self):
		self.assertTrue(Authentication.test_password(username, "Unit_test@123"))
		
		
		
		
# Disable
def disable_print():
    sys.stdout = open(os.devnull, 'w')

# Restore
def enable_print():
    sys.stdout = sys.__stdout__


if __name__ == '__main__':
	username = "__unit_test_" + str(uuid.uuid4()).replace("-", "")
	user = User('', '', '', '', 0)
	
	try:
		# we don't want out standard calls to "print()" to show during testing
		disable_print()
		
		user = Authentication.create_user(f"{username}", "unit", "test", "unit@tests.com", 0, "Unit_test@123")
	
		unittest.main()
	finally:
		user.remove()
		
		enable_print()
		


