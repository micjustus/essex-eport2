import sys

sys.path.append('src')
sys.path.append('src/data')

from mysql_db import MySQLDatabase
from mongo_db import MongoDatabase


def drop_mysql_user_table():
	with MySQLDatabase() as db:
		db.execute("DROP TABLE IF EXISTS users", True)

	print ("Dropped users table.")


def drop_user_tokens_table():
	with MySQLDatabase() as db:
		db.execute("DROP TABLE IF EXISTS tokens", True)

	print ("Dropped users tokens table.")
	

def create_mysql_user_table():
	with MySQLDatabase() as db:
		db.execute("""
		CREATE TABLE users(
			id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
			first_name VARCHAR(35) NOT NULL,
			last_name VARCHAR(35) NOT NULL,
			position VARCHAR(50) NOT NULL,
			email VARCHAR(255) NOT NULL,
			username VARCHAR(128) NOT NULL,
			password CHAR(60) NOT NULL,
			access_lvl TINYINT NOT NULL,
			CONSTRAINT PRIMARY KEY(id))
		""", True)

	print ("New users table created.")


def insert_admin_user():
	with MySQLDatabase() as db:
		db.execute("""

		INSERT INTO
			users(first_name, last_name, position, email, username, password, access_lvl)
		VALUES(
			'Will',
			'Shepherd',
			'Administrator',
			'admin@ict.nasa.gov',
			'admin',
			# Admin123!
			'$2a$10$rXvnliQIa90SNbgWi2qH7.kjQlIEq7dZHziJcGBRvZqFTCxg4yR6q',
			0)
		""", True)

	print ("Default admin user added.")


def create_user_tokens_table():
	with MySQLDatabase() as db:
		db.execute("""
		CREATE TABLE tokens(token_value VARCHAR(50) NOT NULL)
		""", True)

	print ("User token tables created.")


def fetch_mysql_users():
	with MySQLDatabase() as db:
		db.execute("SELECT * FROM users", False)


def drop_mongo_collection():
	MongoDatabase().entries.drop()

	print ("Dropped entries collection.")


def add_default_entries():
	MongoDatabase().entries.insert_many([
		{
			"created": "23-09-2021", "creator": "Andrey Smirnov", "title": "Pressure system SSP 51721", 
			"summary": "Pressure systems can be classified as low pressure or high pressure and can contain fluids or gasses that are considered either hazardous or nonhazardous. Low pressure system are classified as either low energy fail-safe or sealed containers.", 
			"keywords": ["pressure", "system", "container", "hazard"], "related": [], "documents": {}, "sensitivity": 1 
		},
		{
			"created": "23-09-2021", "creator": "Taylor Edgell", "title": "Sealed container in pressure system SSP 51721", 
			"summary": "When the MDP is greater than 100 psia, it is considered a high pressure component and high pressure system safety requirements are applicable. End items that are comprised of more than one pressurized component are considered a pressure system.", 
			"keywords": ["pressure", "system", "container", "hazard"], "related": ["614cb684792646c22da171a6"], 
			"documents": {}, "sensitivity": 2
		},
		{
			"created": "23-09-2021", "creator": "Michael Justus", "title": "Pressure vessel TBR 4-3", 
			"summary": "When the MDP is greater than 100 psia, it is considered a high pressure component and high pressure system safety requirements are applicable. End items that are comprised of more than one pressurized component are considered a pressure system.", 
			"keywords": ["pressure", "system", "container", "hazard"], 
			"related": ["614cb684792646c22da171a6", "614cb7ad792646c22da171a7"], "documents": {}, "sensitivity": 3
		}
	])

	print ("Set up new collection with default entries.")


def create_search_index():
	result = MongoDatabase().entries.create_index(
		[('title', 'text'), ('summary', 'text'), ('keywords', 'text')]
	)

	print ("Created text indexes on the collection.")


def find_in_collection():
	result = MongoDatabase().entries.find()
	for entry in result:
		print(entry)


if __name__ == "__main__":
	try:
		reset_sql = str(input("Proceed with user database reset? (Yes/No): "))
	except ValueError:
		print("Unexpected error, please contact the administrator.")

	if reset_sql == 'Yes':
		drop_mysql_user_table()
		drop_user_tokens_table()
		create_mysql_user_table()
		create_user_tokens_table()
		insert_admin_user()
		fetch_mysql_users()

	try:
		reset_mongo = str(input("Proceed with entry database reset? (Yes/No): "))
	except ValueError:
		print("Unexpected error, please contact the administrator.")

	if reset_mongo == 'Yes':
		drop_mongo_collection()
		add_default_entries()
		create_search_index()
		find_in_collection()

	if reset_sql == 'Yes' or reset_mongo == 'Yes':
		print("Project data successfully reset.")
