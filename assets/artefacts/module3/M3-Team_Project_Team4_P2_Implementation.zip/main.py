import sys

sys.path.append('src')
sys.path.append('src/data')
sys.path.append('src/domain')
sys.path.append('src/domain/auth')
sys.path.append('src/ui')
sys.path.append('src/ui/screens')

# Menu is the starting point to load the main interactive screen
from ui.menu import Menu

if __name__ == "__main__":
	print("About to run the IIS Team Project... ")
	Menu().run()
