mysql;

USE COMPANY1;

# ===============================================================



# 1. List all Employees whose salary is between 1,000 AND 2,000. 
# Show the Employee Name, Department and Salary
# ------------------------------------------------------------------
# Notes
# || We link to the Department table because it has full department 
#    name inside. Merely showing the EMP.DEPNO is insufficient
#    output for 
# 
# || We use a LEFT JOIN because we are starting from the Employees table. 
#    And it *might* be that some employees have not been linked to a 
#    department. In this case, the returned value will be 'NULL'
# 
# || We use column aliasing to make the output columns more understandable 
#
# || We use ORDER BY to present results in easy-to-read manner of sorted results
#    Default sort order is ASC so no need to specify that here.
# ------------------------------------------------------------------


SELECT ENAME AS 'Employee', DEPT.DNAME as 'Department', SAL AS 'Salary'
FROM EMP
LEFT JOIN DEPT ON DEPT.DEPTNO = EMP.DEPTNO
WHERE SAL BETWEEN 1000 AND 2000
ORDER BY Employee;


# ===============================================================


# 2. Count the number of people in department 30 who receive a 
# salary and the number of people who receive a commission
# ------------------------------------------------------------------
# Notes:
# || We use INNER JOIN because we want anm EXACT MATCH of employees
#    in Department 30. Using LEFT JOIN would return those employees
#    who did not have a matching Department, and using RIGHT JOIN 
#    would return those Departments who do not have linked Employees
#
# || COUNT(xxxx) will return non-null entries
#
# || We use NULLIF(EMP.COMM, 0) to filter out any commision values of '0'
#    because to say 'Employee X received a commision of ZERO' makes no 
#    logical sense. NULLIF(...) returns NULL if the expressions are equal. 
#    And since COUNT(...) only counts NON-NULL values, this is a convenient
#    way to filter out zero-based commissioned employees.
#
# || We use column aliasing to make the output columns more understandable 
#
# || The answer returns all Employees with a salary amount, and all Employees
#    with a non-zero commission amount. There are, in the data, some employees
#    who have both a commission AND salary.
# ------------------------------------------------------------------


SELECT COUNT(EMP.SAL) AS Salaried, COUNT(NULLIF(EMP.COMM, 0)) AS Commissioned 
FROM EMP 
INNER JOIN DEPT ON DEPT.DEPTNO = EMP.DEPTNO 
WHERE DEPT.DEPTNO = 30;


# ===============================================================


# 3. Find the name and salary of employees in Dallas.
# ---------------------------------------------------------------
# Notes:
# || We use INNER JOIN because we want an EXACT MATCH of employees
#    in Department whose location equals 'Dallas'.
#
# || We use ORDER BY to present results in easy-to-read manner of sorted results
#    Default sort order is ASC so no need to specify that here.
# ------------------------------------------------------------------


SELECT EMP.ENAME AS Name, EMP.SAL AS Salary
FROM EMP 
INNER JOIN DEPT ON DEPT.DEPTNO = EMP.DEPTNO 
WHERE DEPT.LOC = "DALLAS"
ORDER BY Name;


# ===============================================================


# 4. List all departments that do not have any employees.
# ---------------------------------------------------------------
# Notes:
# || We use LEFT JOIN because we want to start our search from Department.
#    Then we link to Employees based on the foreign key. Since employees
#    record might not be linked to a Department, therefore we test for a 
#    NULL condition (which is what LEFT JOIN will substitute for missing records)
#    by using the clause 'WHERE EMP.EMPNO IS NULL'
#
# || We use ORDER BY to present results in easy-to-read manner of sorted results
#    Default sort order is ASC so no need to specify that here.
# ------------------------------------------------------------------


SELECT DEPT.DNAME AS Department
FROM DEPT 
LEFT JOIN EMP ON DEPT.DEPTNO = EMP.DEPTNO 
WHERE EMP.EMPNO IS NULL
ORDER BY Department;


# ===============================================================


# 5. List the department number and average salary of each department.
# ---------------------------------------------------------------
# Notes:
# || We use LEFT JOIN because we want to start our search from Employee.
#    Then we link to Department based on the foreign key. Since employees
#    record might not be linked to a Department, therefore we use LEFT JOIN
#
# || We use ORDER BY to present results in easy-to-read manner of sorted results
#    Default sort order is ASC so no need to specify that here.
#
# || We use GROUP BY to ensure the AVG(...) function applies to all records
#    with a matching grouing column value, in this case 'EMP.DEPTNO'
# ------------------------------------------------------------------


SELECT EMP.DEPTNO AS DepartmentID, AVG(EMP.SAL) AS Average_Salary
FROM EMP  
LEFT JOIN DEPT ON EMP.DEPTNO = DEPT.DEPTNO 
GROUP BY EMP.DEPTNO
ORDER BY DepartmentID;


# ===============================================================
