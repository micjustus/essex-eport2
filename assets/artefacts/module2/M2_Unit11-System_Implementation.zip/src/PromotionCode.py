from os import times


import datetime

class PromotionCode:
    """Represents a discount code that can be applied by a Customer to their Order.
    """
    def __init__(self, code, days_valid, discount) -> None:
        self.discount_code = code
        self.issue_date = datetime.date.today()
        self.valid_until = days_valid
        
        # Since Unit 7, this attribute is added for completeness
        self.discount_amount = discount
        