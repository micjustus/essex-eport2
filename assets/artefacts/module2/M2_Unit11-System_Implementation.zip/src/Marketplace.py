from typing import List
from Product import Product
from WebsiteSeller import WebsiteSeller
from OrganisationSeller import OrganisationSeller
from IndividualSeller import IndividualSeller

class Marketplace:
    """A collection of one or more Seller instances who provide one or more Products
    for sale. The system will always contain at last one seller, namely the
    WebsiteSeller instance that represents the system's ability to act as a Seller.
    """
    def __init__(self) -> None:
        # Marketplace must by default, always create an instance of WebSiteSeller
        wss = WebsiteSeller()
        self.__sellers= []
        self.__sellers.append(wss)

    def _find_first_seller(self, product: Product):
        """Finds the first registered seller of the specified product."""
        for seller in self.__sellers:
            for prod in seller.catalogue._products:
                if prod.code == product.code:
                    return seller
        
        return None
        
    def find_store_front(self, name):
        """Method not yet used."""
        pass

    def register_individual(self, first_name, last_name ) -> IndividualSeller:
        ind = IndividualSeller(first_name, last_name)
        self.__sellers.append(ind)
        return ind

    def register_organisation(self, trading_name, company_number) -> OrganisationSeller:
        org = OrganisationSeller(trading_name, company_number)
        self.__sellers.append(org)
        return org

    def search_products(self, query) -> List[Product]:
        """Find a single product given the specified query. This function will loop through all registered sellers."""
        matches = []
        
        for s in self.__sellers:
            prods = s.catalogue.search_products(query)
            for p in prods:
                matches.append(p)

        return matches        