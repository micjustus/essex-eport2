from DeliveryOption import DeliveryOption

class StandardDelivery(DeliveryOption):
    """Class that implements parcel delivery using the country's postal service. The
    price for postal service is usually cheaper than courier services. Standard
    delivery is only available to products purchased directly form the website.
    """
    def __init__(self) -> None:
        # Initialise base class attributes
        super().__init__(25, "5 days")

    def __repr__(self) -> str:
        return "StandardDelivery"
