from ShoppingBasket import ShoppingBasket
from OrderState import OrderState

class Order:
    """Represents basic information pertaining to a collection of searched-for
    Products. The Order has a "status" and by itself, serves as a data-object
    <i>before </i>payment is made for one or more Products.
    """
    def __init__(self) -> None:
        self.__shopping_basket= ShoppingBasket()
        self.__state = OrderState.NotStarted
        
    @property
    def state(self):
        """Returns the current state of this order instance"""
        return self.__state

    @state.setter
    def state(self, state: OrderState):
        self.__state = state

    @property
    def shopping_basket(self):
        """Returns the single instance of a shopping basket linked to this order"""
        return self.__shopping_basket
