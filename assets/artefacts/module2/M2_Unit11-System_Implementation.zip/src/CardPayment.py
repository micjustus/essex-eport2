from PaymentDetails import PaymentDetails

class CardPayment(PaymentDetails):
    """Represents a debit/credit card payment."""

    def __init__(self) -> None:
        # We use a test credit card number, obtained from 
        # https://developers.bluesnap.com/docs/test-credit-cards
        # 
        # We do not supply a payment callback here because it is the 
        # Website instance that will provide
        #
        # Initialise base class attributes
        super().__init__("4001919257537193", "", None, None)
        

    def _handle_payment(self, amount):
        # This is a bsic check but obviously, there is are deeper 
        # complexities to submitting credit/debit card payments than
        # we can write here for this small implementation.
        return self.validate_account() and amount > 0

    def validate_account(self):
        # We are hard-coding a check here only for simplicity of Unit 11.
        # However, moving this code into a real-world system, means this 
        # class would employ further complex checks to ensure the account number is
        # a valid credit/debit card number, checks the expiry date and CVC
        # numbers -- attributes not provided yet based on the UML model from 
        # Unit 7
        return self.account_number == "4001919257537193"

    def __repr__(self) -> str:
        return f"CreditCard Payment: {self.account_number}"