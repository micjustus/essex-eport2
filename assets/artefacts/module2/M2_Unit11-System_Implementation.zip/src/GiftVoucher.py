from PaymentDetails import PaymentDetails

class GiftVoucher(PaymentDetails):
    """Represents a gift voucher with a unique code that can be used to 
    part for part (or whole) or a customer's order."""
    def __init__(self, amount) -> None:
        # We do not supply a payment callback here because it is the 
        # Website instance that will provide
        #
        # Initialise base class attributes
        super().__init__("GIFT_VOUCHER", "", None)

        # Amount represents how much value is associated with this gift voucher
        self.amount = amount

    def _handle_payment(self, amount):
        # A gift voucher is valid if the voucher code is valid
        # and the order amount being charged can be covered
        # by the gift voucher amount
        return self.validate_account() and amount - self.amount > 0


    def validate_account(self):
        """Checks to ensure that this gift voucher is valid."""

        # In a real system, there may be more complex requirements
        # to ensuring that a gift voucher is valid, such as checking
        # a databases, or external service
        return self.account_number == "GIFT_VOUCHER"

    def __repr__(self) -> str:
        return f"GiftVoucher: Code={self.account_number}, Amount={self.amount}"
        