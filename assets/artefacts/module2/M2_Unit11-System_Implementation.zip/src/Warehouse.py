from typing import List
from StockDatabase import StockDatabase
from WarehouseStaff import WarehouseStaff
from OrderCheckout import OrderCheckout
from HandheldTerminal import HandheldTerminal
from Package import Package

class Warehouse:
    """An entity that is capable of locating Product instances within a physical
    Warehouse, managing stock levels and packaging the Products for delivery.
    """
    inventory_db = StockDatabase()
    
    def __init__(self) -> None:
        # initialise instance attributes
        self._available_orders = []
        self._staff = []
        self._terminals = []
        self._packages = []

        # let's add a one staff member
        # Ideally, the list of staff members must be retrieved from the system's
        # database
        self._staff.append(WarehouseStaff(self))

        # let's add a single terminal
        # Ideally, the list of available and operational terminals must be retrieved
        # from a hardware management system. Yes, the device information will be 
        # stored and loaded from a database, however it is the hardware manager system
        # that handles integration of terminals with the warehouse's system (this class, 
        # for instance)
        self._terminals.append(HandheldTerminal())


    def add_order_for_delivery(self, item : OrderCheckout):
        """Adds a paid-for checkout to this warehouse instance for a staff member to package"""
        self._available_orders.append(item)


    def get_available_terminal(self) -> HandheldTerminal:
        """Retrieves a single terminal that is not currently in use by other staff members"""

        # In a fully-fledged system, this routine will include far more complex logic
        # that determines what "in use" means for a handheld terminal. For Unit 11, 
        # we simply have a single array of one terminal
        return self._terminals[0]


    def package_order(self, order : OrderCheckout) -> Package:
        """Marks the order as packaged and ready for delivery"""
        package = Package()

        for prod in order.order.shopping_basket._products:
            package.add_product(prod)

        self._packages.append(package)
        return package


    def retrieve_next_order(self) -> OrderCheckout:
        """Retrieves the next order checkout that requires packaing"""
        if len(self._available_orders) > 0:
            # remove the most recent item from the collection and return it
            return  self._available_orders.pop()


    def send_package_for_delivery(self, item : Package):
        """This method is not yet used"""
        pass

    def get_available_staff(self) -> WarehouseStaff:
        """Returns the first staff member available. This is a helper routine 
        to prevent reading local private attribute values"""
        return self._staff[0]