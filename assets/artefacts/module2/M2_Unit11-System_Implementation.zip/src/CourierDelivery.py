from DeliveryOption import DeliveryOption

class CourierDelivery(DeliveryOption):
    """Class that implements courier parcel delivery.
    """
    def __init__(self) -> None:
        # Initialise base class attributes with default values
        # Ideally these values are obtained from the system's database
        super().__init__("25.00", "2 days")

    def __repr__(self) -> str:
        return "CourierDelivery"