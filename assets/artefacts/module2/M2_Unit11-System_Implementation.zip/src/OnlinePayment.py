from PaymentDetails import PaymentDetails

class OnlinePayment(PaymentDetails):
    """Represents a payment faciliated by an external payments provider."""
    def __init__(self) -> None:
        super().__init__("ONLINE_PAYMENT", "", None)

    # For simplicity, we assume submission of payments will succeed
    # Obviously, there is far more deeper complexities to submitting
    # credit/debit card payments than we can write for Unit 11
    def _handle_payment(self, amount):
        return self.validate_account() and amount > 0


    def validate_account(self):
        return self.account_number == "ONLINE_PAYMENT"


    def __repr__(self) -> str:
        return f"Online Payment: {self.account_number}"