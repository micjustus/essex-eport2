from OrderState import OrderState
from Package import Package
from Order import Order

class DeliveryOption:
    def __init__(self, cost, estimate) -> None:
        self.delivery_cost = cost
        self.delivery_estimate = estimate

    def deliver_package(self, package : Package, order: Order):
        """Abstract definition for child instances to override on how to deliver a specified package."""

        order.state = OrderState.Shipped

    def __str__(self) -> str:
        return "DeliveryOptions"