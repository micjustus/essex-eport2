from typing import List
from ProductCatalogue import ProductCatalogue
from StoreFront import StoreFront
from PriceList import PriceList
from DeliveryOption import DeliveryOption

class Seller:
    """A generic class to represent different types of sellers in a MarketPlace.
    """
    def __init__(self) -> None:
        # Initialise instance attributes
        self._product_catalogue= ProductCatalogue()
        self._store_front= StoreFront()
        self._price_list= PriceList()

    @property
    def catalogue(self) -> ProductCatalogue:
        return self._product_catalogue

    # Unfortunately, for completeness, this method was added after the Unit 7
    def _init_price_list(self):
        """Initializes the pprice list with products (and initial) prices from the catalogue"""
        for prod in self._product_catalogue._products:
            self._price_list.add_price(prod.code, prod.price)

    def delivery_options(self) -> List[DeliveryOption]:
        """Returns a collection of supported delivery options"""
        return []
