from StockDatabase import StockDatabase
from Product import Product

class HandheldTerminal:
    """A physical device capable of scanning a Product's barcode. This class also uses
    a StockDatabase instance to automatically update Product stock levels.
    """
    def pickup_stock(self, item : Product, stock_db : StockDatabase):
        """Scans a product's barcode and update's the stock database's inventory levels"""
        if item.code is None:
            return

        stock_db.adjust_stock_level(item.code, -1)