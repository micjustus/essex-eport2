from typing import List
from DeliveryOption import DeliveryOption
from Seller import Seller
from StandardDelivery import StandardDelivery

class ThirdPartySeller(Seller):
    """Represents external Sellers who wish to sell their wares via the system.
    """
    def __init__(self) -> None:
        # Initialise base class attributes
        super().__init__()
        
        # Initialise instance attributes
        self._standard_delivery= StandardDelivery()

    def delivery_options(self) -> List[DeliveryOption]:
        """Returns a collection of support delivery options"""
        return [self._standard_delivery]
