
from Package import Package

class WarehouseStaff:
    """A human entity that fulfills order checkouts and packages the Products
    (carefully) for delivery.
    """
    def __init__(self, warehouse) -> None:
        # Initialise instance attributes
        self._warehouse = warehouse

    def package_next_order(self) -> Package:
        """Retrieves the next available order from a warehouse, scans all required products and packages the order for delivery"""
        from Warehouse import Warehouse

        terminal = self._warehouse.get_available_terminal()

        # [UML_Activity_Step]: Retrieve order from picklist
        checkout  = self._warehouse.retrieve_next_order()
        if checkout is not None:
            # iterate the products in the original order's shopping basket,
            # and scan via the terminal.
            for prod in checkout.order.shopping_basket._products:
                # [UML_Activity_Step]:  Scan order items on terminal
                terminal.pickup_stock(prod, Warehouse.inventory_db)

                # [UML_Activity_Step]:  Retrieve physical product from location
                loc = Warehouse.inventory_db.locate_stock_item(prod.code)

            # The product has been scanned, stock levels updated
            # Now the goodies are packaged into earth-friendly plastic and copious
            # layers of box-within-a-box boxes. 
            
            # [UML_Activity_Step]: Place package in dispatch area
            return self._warehouse.package_order(checkout)
