from DeliveryOption import DeliveryOption
from OrderState import OrderState
from Warehouse import Warehouse
from CardPayment import CardPayment
from DeliveryAddress import DeliveryAddress
from typing import List
from OrderCheckout import OrderCheckout
from Order import Order
from PromotionCode import PromotionCode
from Product import Product
from Marketplace import Marketplace
import random

class Website:
    """The main interaction point between a Customer. Seller and Warehouse. This class
    represents front-end interactions and therefore contains the most number of
    operations because all actions performed by a Customer require some form of
    visual input and acknowledgment.
    """
    
    # class variables, since we only have a single webSite to worry about
    __current_order= Order()
    __promo_codes= []
    
    @property
    def marketplace(self):
        """Gets the single marketplace instance associated to this website. This
        property is readonly."""
        return self.__marketplace

    @property
    def warehouse(self):
        """Gets the associated warehouse instance used by this website to 
        trigger a request for order packaging and delivery. This property is 
        readonly"""
        return self.__warehouse
        
    def __init__(self):
        # Ideally, we want the warehouse to be a REST-based API call, instead
        # of instantiating it here. This is because the warehouse realistically
        # is an external system separate from the customer-facing website.
        # However, for Unit 11, it is OK to create an instance of this object
        # since the object can easily be swapped out for service-references.
        self.__marketplace = Marketplace()
        self.__warehouse = Warehouse()
        
        # we initialize this object instance to None because the 
        # "checkout()" will correctly set this attribute
        self._checkout = None

        # holds the products selected by a customer. This is a dynamic
        # list that grows and shrinks as customers add or remove items 
        # to be added to their shopping basket
        self._selected_products = []


    def capture_delivery_details(self, checkout: OrderCheckout):
        """Facilitates capturing delivery details from a logged on customer."""
        
        def _get_delivery_option() -> DeliveryOption:
            """Method to determine the appropriate deliveyr option based on the seller
            the customer wishes to purchase products from."""
            sellers =[]

            for prod in checkout.order.shopping_basket._products:
                seller = self.marketplace._find_first_seller(prod)
                if not seller in sellers:
                    sellers.append(seller)

            # If we found > 1 seller, for Unit 11, we just take the FIRST seller
            if len(sellers) > 0:
                sell = sellers[0]
                return sell.delivery_options()[0]
            
        # Since we are not utilising a GUI framework, we  provide a default 
        # set of delivery details to EMULATE the data that would be captured
        # by a customer, as a result of this method. 
        #
        # This method ideally displays a separate web page that provides a place
        # for the customer to enter their delivery address details...

        checkout.delivery_details.delivery_address = DeliveryAddress("GB", "13 Highway Road", "Ringroad", "Sherwood Forrest", "AM 995Y")
        
        # ... also, the website will determine the appropriate delivery option
        # based on the sellers we are purchasing products from. 
        option = _get_delivery_option()
        checkout.delivery_details.delivery_option = option


    def capture_payment_details(self, checkout: OrderCheckout):
        """Facilitates capturing delivery options from a logged on customer."""

        # The callback method "customer_has_paid()" is raised by the PaymentDetails
        # instance after a call to "submit_payment". This allows us to handle updates 
        # of the order's state in response to a customer completing their order payment
        # without passing dependency on Order to each payment type child.
        # 
        # The idea is single-responsibility, and payment details knows about an order
        # and therefore is solely responsible for changing its state.

        def customer_has_paid():
            checkout.order.state = OrderState.AwaitingPicking

        def customer_not_paid():
            checkout.order.state = OrderState.Processing


        # Since we are not utilising a GUI framework, we will provide a default 
        # payment information instance (CARD PAYMENT)

        checkout.payment_details = CardPayment()
        checkout.payment_details._payment_submitted = customer_has_paid
        checkout.payment_details._payment_failed = customer_not_paid
        checkout.order.state = OrderState.PendingPayment
        

    def change_storefront(self, name):
        """Changes the current search portal to the selected storefront specified by the name"""
        pass


    def checkout(self, order: Order) -> OrderCheckout:
        """Initiates the checkout process that will walk the customer through providing additional 
        details for payment and delivery."""

        self._checkout = OrderCheckout(order)
        order.state = OrderState.Processing
        return self._checkout


    def create_promocode(self, days_valid) -> PromotionCode:
        """Creates a new promo-code that can be used by customers at checkout to apply a discount."""
        val = random.randint(1, 999999)
        ch1 = chr(random.randint(65, 92)) + chr(random.randint(65,92))
        code = ch1 + str(val)

        # We add a key-value pair instance to promo codes
        promo = PromotionCode(code, days_valid, 0.25)
        self.__promo_codes.append(promo)

        return promo

        
    def logon(self, customer) -> Order:
        """Initiates a new order instance at the moment a customer logs onto the website. The 
        newly created order instance will automatically be associated to the customer."""
        if self._checkout is not None:
            print(f"Sorry, another order is in progress. OrderNumber={self._checkout.order_number}, State={self._checkout.order.state}.")
            return self.__current_order

        self.__current_order = Order()
        self.__current_order.state = OrderState.InProgress

        # Although we set a protected attribute on Customer ("_order"), 
        # this is acceptable because Customer and Order are both within the same 
        # access control domain. 
        #
        # # If Customer and Order crossed boundaries, we would definitely not
        # allow external classes to modify the internal properties of a 
        # class they are not permitted to.
        customer._order = self.__current_order

        return self.__current_order

    def logoff(self):
        if self.__current_order is not None:
            self.__current_order.state = OrderState.NotStarted
            
            if self._checkout is not None:
                self._checkout.order = None

            
    def schedule_order_for_delivery(self, checkout: OrderCheckout) -> None:
        # [UML_Activity_Step]: Add order to pick list
        self.__warehouse.add_order_for_delivery(checkout)
        checkout.order.state = OrderState.ReadyForDelivery


    def search_marketplace(self, query) -> List[Product]:
        """Searches for the specified product by code or description, across all sellers within the marketplace."""
        return self.__marketplace.search_products(query)


    def search_products(self, search_query) -> List[Product]:
        """This method is unused"""
        pass


    def show_products(self, list) -> None:
        """Populates the lit of products onto a new user-interface page which the customer
        can interact with to select items."""

        # Since we are not using a GUI framework, this method does not do anything special
        self._selected_products = list


    def get_selected_products(self) -> List[Product]:
        """This method returns the products that a customer had selected
        from a list of products populated by the 'show_products' method"""

        # For simplicity, we simply return the items that were 
        # initially populated 
        return self._selected_products