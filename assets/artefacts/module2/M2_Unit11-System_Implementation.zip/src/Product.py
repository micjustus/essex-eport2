import random

class Product:
    """An item that is sellable via a website.
    """
    def __init__(self, name, description, price, product_code):
        # Initialise instance attributes
        self.name = name
        self.description = description
        self.price = price
        self.code = product_code
        
        # Since Unit 7, this attribute is added for completeness
        self.weight = random.randint(0, 200)

    @staticmethod
    def empty_product():
        """Creates a product instance that has not data associated with it"""
        return Product("", "", 0, "")
    
    def __repr__(self) -> str:
        return f"{self.name} ({self.code}) costs {self.price}"

