
# Unit 11 system implementation
#
# # The following code demonstrates practical implementation of the 
# UML  activity model presented in Unit 7.


from Website import Website
from Product import Product
from Customer import Customer
from Order import Order

def setup_sellers(web: Website):
    org = web.marketplace.register_organisation("Glamazon", "Where cheap glam comes at a price")
    person = web.marketplace.register_individual("TinyTimsToyStore", "Well... someone's gotta lead the charge!")

    print("Registered two sellers.")

    #----------------------------------------------------------
    # Now that we have sellers, let's assign products to each one
    p1 = Product("Jelly_Tots", "Delicious, chewy sugar-coated squishy treat things", 2.99, "JT-01")
    p2 = Product("Sneeky_Shoes", "Generic pair of two sneakers, useful indoors", 15.00, "SS-01")
    p3 = Product("Many_Dots", "A book about one hundred and one Dalmatians", 14.99, "MD-01")
    p4 = Product("Blender", "An easy-to-use blender for those times you need to mish-mash good ideas", 25, "KB-01")
    p5 = Product("Sponge_Bobs", "Tasty, spongey treats filled with vanilla or custard. Pack of 6.", 4.5, "SB-01")

    # Please note, for the purpose of Unit 11 deliverable, the code is kept
    # as simple as possible. This means (for this demonstration) that no two sellers sell the SAME product, as is
    # found in a real-world system. This ensures product search functionality remains
    # on-point and demonstrates UML-to-Python skill.
    #
    # Adding products to a catalogue will automatically add the product to the system's StockDatabase instance
    org.catalogue.add_product(p1, 10)
    org.catalogue.add_product(p3, 45)
    org.catalogue.add_product(p5, 120)

    person.catalogue.add_product(p2, 6)
    person.catalogue.add_product(p4, 44)

    #----------------------------------------------------------
    # Let's add some products that are Out Of Stock (quantity = 0)
    p6 = Product("BrusselSprouts", "A vegetable. Tiny but mighty. Hunts in packs of 24", 0.79, "BS-01")
    org.catalogue.add_product(p6, 0)

    print("Added products to sellers' catalogues.")

    # For completeness, we need to ensure the price lists are populated
    org._init_price_list()
    person._init_price_list()

    print("Initialised sellers' price lists.")


def search_for_products(web:Website, customer: Customer, order: Order):
    """This process models the "Search for products" UML activity"""
    
    # PLEASE NOTE: for simplicity, the searches are limited to products from 
    # a single seller since each seller has different delivery options.
    # for this reason the complexities behind creating MULTIPLE (behind-the-scenes)
    # checkouts for each type of delivery (based on the the seller of the products) 
    # is left out from this code

    # [UML_Activity_Step]: Enter a product search query
    matches = web.search_marketplace("custard")
    if len(matches) == 0:
        return 

    print(f"Searched for 'custard'. Found={len(matches)}")

    # [UML_Activity_Step]: Show search results
    web.show_products(matches)
    print("Showing the products on front end.")

    # [UML_Activity_Step]: 
    selected = web.get_selected_products()
    order.shopping_basket.add_products(selected)
    print(f"Products added to basket. Items in basket={len(order.shopping_basket._products)}")

    #----------------------------------------------------------
    # [UML_Activity_Step]: Select one or more products
    matches = web.search_marketplace("tiny but mighty")

    # [UML_Activity_Step]: Add products to basket
    order.shopping_basket.add_products(matches)
    
    #----------------------------------------------------------
    process_payment(web)


def process_payment(web: Website):
    # [UML_Activity_Step]: Start checkout process
    checkout = web.checkout(order)
    print(f"Requested checkout process for order#: {checkout.order_number}")

    # [UML_Activity_Step]: Select delivery option
    # [UML_Activity_Step]: Provide delivery address details
    web.capture_delivery_details(checkout)
    print(f"Captured delivery details. Line1={checkout.delivery_details.delivery_address.line1}...")
    print(f"Captured delivery option={checkout.delivery_details.delivery_option}")

    while True:
        # [UML_Activity_Step]: Enter new payment details
        web.capture_payment_details(checkout)
        print(f"Captured payment details={checkout.payment_details}; account number={checkout.payment_details.account_number}")

        # if the customer wishes to reuse payment details for their selected payment 
        # type, then we will use the following code path:
        #
        # [UML_Activity_Step]: Load stored payment details
        # checkout.payment_details.retrieve_payment_details()
        
        if checkout.payment_details.validate_account() == True:
            print("Payment details are validated.")
            break
    
    checkout.calculate()
    print(f"Total amount payable (before promo code)={checkout.total_amount}")

    # [UML_Activity_Step]: Add promotion code
    # For this sample, we will add a promo code
    promo_code = web.create_promocode(10)
    checkout.payment_details.add_promo_code(promo_code)
    print(f"\tAdded a promo code to payment details={promo_code.discount_code}. Discount={promo_code.discount_amount}")

    checkout.calculate()
    print(f"Total amount payable (after promo code)={checkout.total_amount}")

    # [UML_Activity_Step]: Make payment
    if checkout.payment_details.submit_payment(checkout.total_amount) == True:
        print("Payment submitted.")

        # [UML_Activity_Step]: Pass order to warehouse
        # [UML_Activity_Step]: Add order to picklist
        web.schedule_order_for_delivery(checkout)
        print("Order sent to the warehouse")

        # At this point, the customer has completed their order and may continue with 
        # a new order. This is achieved by issuing a new "Logon" request to the Website
        # instance
        #
        # In a more complex system, warehouse staff would receive notifications
        # that a checkout requires packaging, OR the staff could log onto their warehouse
        # app and begin processing orders. For Unit 11, we simulate that scenario here
        # by working directly with a staff member

        # [UML_Activity_Step]: Retrieve order from picklist
        staff = web.warehouse.get_available_staff()
        package = staff.package_next_order()
        print(f"[Warehouse] staff member retrieved order and packaged. Total weight={package._package_weight}")

        # OK, the staff member has now packaged the item, good. 
        # Let's send the package to the selected delivery company

        # [UML_Activity_Step]: Send package to selected delivery company
        # [UML_Activity_Step]: Deliver package to customer's address
        checkout.delivery_details.delivery_option.deliver_package(package, checkout.order)
        print("Package has been delivered")

if __name__ == "__main__":
    # First, we have to initialise the basic environment
    web = Website()

    setup_sellers(web)
 
    # [UML_Activity_Step]: Log onto website
    customer = Customer("XYZ0001", "SAMPLE_ACCOUNT")
    order = web.logon(customer)
    if order is not None:
        search_for_products(web, customer, order)