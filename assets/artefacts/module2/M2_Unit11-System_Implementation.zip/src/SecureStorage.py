class SecureStorage:
    """Represents a secure location within the system to store and retrieve payment
    details.
    """
    def __init__(self) -> None:
        # Instantiate private instance attributes
        self.__account_number = ""
        self.__sort_code = ""

    def load_data(self):
        """Retrieves payment details from secure storage"""
        return {
            "account": self.__account_number,
            "sort_code": self.__sort_code
        }

    def save_data(self, value):
        """Persists payment details to secure storage"""
        self.__account_number = value.account_number
        self.__sort_code = value.sort_code