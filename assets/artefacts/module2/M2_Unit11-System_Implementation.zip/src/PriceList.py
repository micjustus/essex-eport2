class PriceList:
    """Provides price information for specific products sold by a Seller.
    """
    def __init__(self) -> None:
        # Initialise instance attributes
        self._version = 1
        self.__prices = []
        
    def add_price(self, product_code, price):
        code = {
            "code": product_code,
            "price": price
        }

        self.__prices.append(code)

    def get_price(self, product_code) -> float:
        """Returns the current price associated to the specified product code"""
        for p in self.__prices:
            if product_code in p.code:
                return p.price

        return 0
