from Product import Product
from ProductCatalogue import ProductCatalogue

class StoreFront:
    """A webpage or other user-interface representation that can display a catalog of
    products on a website.
    """
    def __init__(self) -> None:
        # Initialise instance attributes
        self._catalog= ProductCatalogue()

    def search_products(self, query) -> Product:
        """This method is not yet used"""
        pass