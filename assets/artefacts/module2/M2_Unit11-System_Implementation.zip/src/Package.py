from Product import Product


from Product import Product

class Package:
    """Represents a physical, packaged box containing the stock items matching a
    Customer's Order request.
    """
    def __init__(self) -> None:
        self._package_weight = 0
        self._products = []

    # Added for completeness since Unit 7
    def add_product(self, product: Product):
        self._products.append(product)
        self._package_weight += product.weight