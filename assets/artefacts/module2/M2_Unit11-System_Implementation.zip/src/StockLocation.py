class StockLocation:
    """Information related to a physical location within a Warehouse that holds one or
    more Product instances as well as the quantity available.
    """
    def __init__(self) -> None:
        # Initialise instance attributes
        self.location_name = ""
        self.stock_level = 0
        
    
