from Warehouse import Warehouse
from typing import List
from Product import Product
from PriceList import PriceList

class ProductCatalogue:
    """Represents a collection of products that can be sold by a seller.
    """

    def __init__(self) -> None:
        # Instantiate private instance attributes
        self._products = []
        self.__levels = {}

    def add_product(self, item: Product, quantity) -> None:
        """Adds a new product to this catalogue"""

        self._products.append(item)
        self.__levels[item.code] = quantity

        # add the product to the warehouse's stock database
        # We access the inventory db through the class attribute 
        # since there must always exist only ONE instance of an
        # inventory database. 
        Warehouse.inventory_db.add_stock_item(item, quantity)

        
    def search_products(self, query) -> List[Product]:
        """Searches for a product within this catalogue by the specified product name or description"""
        matches = []

        # Search for a partial match in either the product name or description
        for p in self._products:
            if query in p.name or query in p.description:
                matches.append(p)
        
        return matches
        
    def update_prices(self, price_list: PriceList) -> None:
        """Updates the price for all products specified in the given price list instance."""
        for p in self._products:
            price = price_list.get_price(p.code)
            p.price = price
