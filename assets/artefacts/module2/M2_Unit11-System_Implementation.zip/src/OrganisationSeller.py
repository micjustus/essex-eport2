from ThirdPartySeller import ThirdPartySeller

class OrganisationSeller(ThirdPartySeller):
    """Represents a legal entity capable of selling their wares via the system.
    """
    def __init__(self, trading_name, company_number) -> None:
        super().__init__()
        
        self.trading_name = trading_name
        self.company_number = company_number
        