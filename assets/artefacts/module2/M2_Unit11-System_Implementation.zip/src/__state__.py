from Customer import Customer
from Website import Website

TITLE = "Testing order state changes..."

def test_order_state_change_logon():
    web = Website()
    order = web.logon(Customer("", ""))
    print(TITLE + f"Logon, Expect=InProgress. Got={order.state}")


def test_order_state_change_logon_logoff():
    web = Website()
    order = web.logon(Customer("", ""))
    web.logoff()
    print(TITLE + f"Logoff after logon. Expect=NotStarted. Got={order.state}")


def test_order_state_change_checkout():
    web = Website()
    order = web.logon(Customer("", ""))
    web.checkout(order)
    print(TITLE + f"Checkout. Expect=Processing. Got={order.state}")


def test_order_state_change_checkout_payment_details():
    web = Website()
    order = web.logon(Customer("", ""))
    checkout = web.checkout(order)

    web.capture_payment_details(checkout)
    print(TITLE + f"Capture payment details. Expect=PendingPayment. Got={order.state}")


def test_order_state_change_checkout_payment_failed():
    web = Website()
    order = web.logon(Customer("", ""))
    checkout = web.checkout(order)
    web.capture_payment_details(checkout)

    checkout.payment_details.submit_payment(0)
    print(TITLE + f"Payment failed. Expect=Processing. Got={order.state}")


def test_order_state_change_checkout_payment_warehouse():
    web = Website()
    order = web.logon(Customer("", ""))
    checkout = web.checkout(order)
    web.capture_payment_details(checkout)

    checkout.payment_details.submit_payment(100)
    print(TITLE + f"Payment succeeded. Expect=AwaitingPicking. Got={order.state}")


def test_order_state_change_warehouse_picked():
    web = Website()
    order = web.logon(Customer("", ""))
    checkout = web.checkout(order)
    web.capture_payment_details(checkout)

    checkout.payment_details.submit_payment(100)

    web.schedule_order_for_delivery(checkout)
    print(TITLE + f"Warehouse packaged. Expect=ReadyForDelivery. Got={order.state}")


def test_order_state_change_warehouse_delivered():
    web = Website()
    order = web.logon(Customer("", ""))
    checkout = web.checkout(order)
    web.capture_payment_details(checkout)

    checkout.payment_details.submit_payment(100)

    web.schedule_order_for_delivery(checkout)

    package = web.warehouse.package_order(checkout)
    checkout.delivery_details.delivery_option.deliver_package(package, order)
    print(TITLE + f"Delivered. Expect=Shipped. Got={order.state}")

    
if __name__ == "__main__":    
    test_order_state_change_logon()
    test_order_state_change_logon_logoff()
    test_order_state_change_checkout()
    test_order_state_change_checkout_payment_details()
    test_order_state_change_checkout_payment_failed()
    test_order_state_change_checkout_payment_warehouse()
    test_order_state_change_warehouse_picked()
    test_order_state_change_warehouse_delivered()