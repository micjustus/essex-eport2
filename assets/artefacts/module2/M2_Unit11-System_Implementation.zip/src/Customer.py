import Product
import Order

class Customer:
    """Represents a logon entity that is capable of initiating an Order and purchasing
    Products.
    """
    def __init__(self, account_id, name) -> None:
        self.account_id = account_id
        self.account_name = name
        
