from ThirdPartySeller import ThirdPartySeller

class IndividualSeller(ThirdPartySeller):
    """Represents a legal person capable of selling their wares via the system.
    """
    def __init__(self, first_name, last_name) -> None:
        # Initialise base class attributes
        super().__init__()
        
        self.first_name = first_name
        self.last_name = last_name
        