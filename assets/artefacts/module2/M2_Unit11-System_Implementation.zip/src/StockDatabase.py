import random

class StockDatabase:
    """Represents an inventory database that holds basic information about Product
    instances such as their location and available quantiy.
    """
    def __init__(self) -> None:
        # Initialise instance attributes
        self._locations= []

    def add_stock_item(self, item, quantity) -> None:
        """Assigns the specified product to a random location within the warehouse."""
        lane = random.randint(0, 100)        

        # First ensure the product is not yet already allocated to a shelf
        location = self.locate_stock_item(item.code)
        if location is None:
            self._locations.append({
                "barcode": item.code,
                "qty": quantity,
                "aisle": lane
            })
        else:
            self.adjust_stock_level(item.code, quantity)


    def adjust_stock_level(self, item_barcode, quantity):
        """Increases/decreases stock in a particular aisle."""
        loc = self.locate_stock_item(item_barcode)
        if loc is not None:
            loc.qty = loc.qty + quantity
        

    def locate_stock_item(self, product_barcode):
        """Locates the specified product with a given barcode or returns 'None' if a location is not assigned."""
        for loc in self._locations:
            # We chack whether or not the attribute exists before accessing it
            # otherwise the code will throw an exception
            if hasattr(loc, "barcode") and loc.barcode == product_barcode:
                return loc
        