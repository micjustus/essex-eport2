class DeliveryAddress:

    def __init__(self,  country, line1, line2, line3, post_code) -> None:
        self.country = country
        self.line1 = line1
        self.line2 = line2
        self.line3 = line3
        self.post_code = post_code
    