from DeliveryAddress import DeliveryAddress
from DeliveryOption import DeliveryOption

class DeliveryDetails:
    """Contains information related to the target address where the Order must be
    delivered as well as the Customer's preferred delivery option (if supported).
    """
    def __init__(self) -> None:
        self.delivery_address= DeliveryAddress("", "", "", "", "")
        self.delivery_option= DeliveryOption(0, "")

