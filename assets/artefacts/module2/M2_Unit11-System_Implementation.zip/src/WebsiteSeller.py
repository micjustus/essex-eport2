from DeliveryOption import DeliveryOption
from typing import List
from Seller import Seller
from StandardDelivery import StandardDelivery
from CourierDelivery import CourierDelivery

class WebsiteSeller(Seller):
    """Represents the internal system acting as a Seller.
    """
    def __init__(self) -> None:
        # Initialise base class attributes
        super().__init__()

        # Initialise instance attributes
        self._standard_delivery= StandardDelivery()
        self._courier_delivery= CourierDelivery()
        
    def delivery_options(self) -> List[DeliveryOption]:
        """Returns a collection of supported delivery options"""
        return [
            self._standard_delivery,
            self._courier_delivery
        ]


