from typing import List
from Product import Product

class ShoppingBasket:
    """Represents a virtual basket that temporarily holds a collection of Product
    instances. This basket is used during the checkout process.
    """
    def __init__(self) -> None:
        # Initialise instance attributes
        self._products = []
        
    def add_products(self, items: List[Product]):
        """Adds the collection of products to this instance"""

        # For simplicity, we do not check for duplicates based on the product's code
        for item in items:
            self._products.append(item)
            