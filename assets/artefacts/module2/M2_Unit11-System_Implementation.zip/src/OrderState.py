import enum

class OrderState(enum.Enum):
    InProgress = 1
    NotStarted = 0
    Processing = 2
    PendingPayment = 3
    AwaitingPicking = 5,
    ReadyForDelivery = 6
    Shipped = 7
