# The following are tests to demonstrate the polymorphic behaviour of the UML model
# presented in Unit 7

from Warehouse import Warehouse
from Website import Website
from PaymentDetails import PaymentDetails
from ThirdPartySeller import ThirdPartySeller
from WebsiteSeller import WebsiteSeller
from Seller import Seller
from OrganisationSeller import OrganisationSeller
from IndividualSeller import IndividualSeller

from CardPayment import CardPayment
from OnlinePayment import OnlinePayment
from GiftVoucher import GiftVoucher

from Website import Website
from Order import Order
from Customer import Customer

def test_seller_types():
   
    print(f"Testing seller types...")

    # test that base class does not have properties of its children
    third = ThirdPartySeller()
    print(f"\t[ThirdPartySeller] Has 'TradingName'? " + str(hasattr(third, "trading_name")))
    print(f"\t[ThirdPartySeller] Has 'CompanyNumber'? " + str(hasattr(third, "company_number")))
    print(f"\t[ThirdPartySeller] Is either 'OrganisationSeller' or 'IndividualSeller'? " + str(third is OrganisationSeller or third is IndividualSeller))
    print(f"\t[ThirdPartySeller] Is subtype of Seller? " + str(issubclass(ThirdPartySeller, Seller)))

    print(f"\t[WebsiteSeller] Is subtype of Seller? " + str(issubclass(WebsiteSeller, Seller)))

    print(f"\t[OrganisationSeller] Is subtype of Seller? " + str(issubclass(OrganisationSeller, Seller)))
    print(f"\t[OrganisationSeller] Is subtype of ThirdPartySeller? " + str(issubclass(OrganisationSeller, ThirdPartySeller)))

    print(f"\t[IndividualSeller] Is subtype of Seller? " + str(issubclass(IndividualSeller, Seller)))
    print(f"\t[IndividualSeller] Is subtype of ThirdPartySeller? " + str(issubclass(IndividualSeller, ThirdPartySeller)))

def test_seller_base():
    # Accessing properties through base class using polymorphism

    print("Testing Seller class")

    def test_seller_base_access(seller: Seller):
        print(f"\t[Seller] type is " + str(type(seller)))
        print(f"\t[Seller] Delivery options = " + str(seller.delivery_options()))

    # Demonstrate that we have a single delivery option
    orgseller = OrganisationSeller("TRADING", "COMPANY")
    test_seller_base_access(orgseller)

    # Demonstrate the we have two types of delivery options available
    webseller = WebsiteSeller()
    test_seller_base_access(webseller)


def test_card_payments():
    """Tests the polymorphic behaviour of the various payment detail classes"""

    print("Testing PaymentDetails...")

    def test_card_payments_submit(payment: PaymentDetails):
        # We're accessing operations using the base class in order to demonstrate
        # the polymorphic behaviour

        print(f"\t[{type(payment)}] Submit payment = {payment.submit_payment(100)}")
        print(f"\t[{type(payment)}] Validate account = {payment.validate_account()}")


    test_card_payments_submit(GiftVoucher(150))
    test_card_payments_submit(CardPayment())
    test_card_payments_submit(OnlinePayment())
    test_card_payments_submit(PaymentDetails("", ""))


#*********************************

if __name__ == "__main__":
    test_seller_types()
    test_seller_base()
    test_card_payments()
