from DeliveryDetails import DeliveryDetails
from PaymentDetails import PaymentDetails
from Order import Order

class OrderCheckout:
    """Represents the final stages of a Customer's shopping experience. It contains
    their payment details and delivery preferences.
    """
    # This private class attribute is incremented each time a new OrderCheckout
    # instance is created. This emulates the concept of an AUTO_INCREMENT 
    # key of a DB table. 
    __order_number = 1

    def __init__(self, order: Order):
        self.order_number = "ORDER #" + str(OrderCheckout.__order_number)
        self.total_amount = 0
        self.total_vat = 0
        self.delivery_details= DeliveryDetails()
        self.payment_details= PaymentDetails("", "")
        self.order = order

        OrderCheckout.__order_number += 1

    # For completeness, this functionality was added after Unit 7
    def calculate(self):
        """Calculates the total amount due (including any discount from a promo code)"""
        self.total_amount = 0
        self.total_vat = 0

        for prod in self.order.shopping_basket._products:
            self.total_amount += prod.price
        
        discount= 0
        if self.payment_details.promo_code is not None:
            discount = self.total_amount * self.payment_details.promo_code.discount_amount
        
        self.total_amount -= discount
        self.total_vat = self.total_amount * 0.2
        

