from PromotionCode import PromotionCode
from SecureStorage import SecureStorage

class PaymentDetails:
    """Represents payment account details relevant to the selected payment method.
    """
    def __init__(self, account_number, sort_code, payment_submitted_callback = None, payment_failed_callback = None) -> None:
        self._payment_submitted = payment_submitted_callback
        self._payment_failed = payment_failed_callback

        self._secure_storage= SecureStorage()
        self.promo_code= None
        self.account_number = account_number
        self.sort_code = sort_code


    def add_promo_code(self, code: PromotionCode):
        """Adds a promotion code to this payment"""
        self.promo_code = code
        

    def retrieve_payment_details(self):
        """Retrieves payment details from the website's secure storage mechanism"""
        value = self._secure_storage.load_data()
        self.account_number = value.account_number
        self.sort_code = value.sort_code        


    def store_payment_details(self):
        """Persists payment details to the website's secure storage mechanism"""

        # We use a dictionary type here since there is no need to represent
        # a new separate data type here. However, usually this is preferred,
        # but not necessary for this simple implementation.
        self._secure_storage.save_data({ "account_number": self.account_number, "sort_code": self.sort_code })


    def submit_payment(self, amount):
        """Abstract function that facilitates paying an order amount"""

        # UML model in Unit 7 shows GiftVoucher, CardPayment and OnlinePayment
        # override this method. However, we introduce a slight variation on the design
        # because we want to notify a callback when a payment was completed.
        #
        # We do not want to pass an Order instance into specific payment
        # child instances, because they should not know about an order; rather, 
        # only what it means to complete a specific payment. 

        result = self._handle_payment(amount)
        if result == True and self._payment_submitted is not None:
            self._payment_submitted()
        elif self._payment_failed is not None:
            self._payment_failed()

        return result


    def validate_account(self):
        """Abstract function that ensures account details are validated and correct"""
        return False
    

    # protected method for 
    def _handle_payment(self, amount):
        pass
 

    def __repr__(self) -> str:
        return f"<PaymentDetails>"